import prisma from "@/lib/prisma";
import { calculateProfit } from "@/lib/sku";
import { Search } from "lucide-react";
import Link from "next/link";

export default async function ProfitPage({ searchParams }: { searchParams: { sort?: string } }) {
  const { sort } = searchParams;

  // 获取所有有核价和报价的商品
  const products = await prisma.product.findMany({
    include: {
      merchant: { include: { market: true } },
      category: true, deviceModel: true, color: true,
      temuPricing: true,
      quotes: true,
    },
  });

  // 计算利润
  const profitData = products
    .filter(p => p.temuPricing && p.quotes.length > 0)
    .map(p => {
      const quote = p.quotes[0];
      const result = calculateProfit({
        temuPrice: p.temuPricing!.temuPrice,
        supplierPrice: quote.supplierPrice,
        logisticsCost: quote.logisticsCost,
        platformFee: quote.platformFee,
        extraCost: quote.extraCost,
      });
      return { product: p, ...result };
    });

  // 排序
  if (sort === 'profit') profitData.sort((a, b) => b.预估利润 - a.预估利润);
  else if (sort === 'rate') profitData.sort((a, b) => b.利润率 - a.利润率);
  else profitData.sort((a, b) => b.利润率 - a.利润率);

  const recommended = profitData.filter(p => p.建议标签 === '推荐').length;
  const observable = profitData.filter(p => p.建议标签 === '可观察').length;
  const notRecommended = profitData.filter(p => p.建议标签 === '不建议').length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-800">📊 利润分析</h1>
      </div>

      {/* 统计 */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
          <p className="text-3xl font-bold text-green-600">{recommended}</p>
          <p className="text-sm text-green-700">推荐 (≥30%)</p>
        </div>
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 text-center">
          <p className="text-3xl font-bold text-yellow-600">{observable}</p>
          <p className="text-sm text-yellow-700">可观察 (20-30%)</p>
        </div>
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-center">
          <p className="text-3xl font-bold text-red-600">{notRecommended}</p>
          <p className="text-sm text-red-700">不建议 (&lt;20%)</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border p-4">
        <form className="flex gap-4 items-center">
          <span className="text-sm text-slate-500">排序:</span>
          <select name="sort" defaultValue={sort} className="border rounded-lg px-4 py-2">
            <option value="rate">按利润率</option>
            <option value="profit">按利润金额</option>
          </select>
          <button type="submit" className="bg-slate-100 px-4 py-2 rounded-lg hover:bg-slate-200">排序</button>
        </form>
      </div>

      <div className="bg-white rounded-xl border overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50 border-b">
            <tr>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">SKU</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">商品</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">Temu核价</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">成本</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">预估利润</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">利润率</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">状态</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {profitData.map((item) => (
              <tr key={item.product.id} className="hover:bg-slate-50">
                <td className="p-3"><code className="text-xs bg-slate-100 px-2 py-1 rounded">{item.product.skuCode}</code></td>
                <td className="p-3 text-sm">{item.product.category.name} | {item.product.deviceModel.name}</td>
                <td className="p-3 font-medium text-orange-600">¥{item.product.temuPricing?.temuPrice}</td>
                <td className="p-3 text-sm text-slate-500">
                  ¥{item.product.quotes[0].supplierPrice + item.product.quotes[0].logisticsCost + item.product.quotes[0].platformFee + item.product.quotes[0].extraCost}
                </td>
                <td className="p-3 font-bold text-green-600">¥{item.预估利润}</td>
                <td className="p-3 font-bold">{item.利润率}%</td>
                <td className="p-3">
                  <span className={`px-2 py-1 rounded-full text-xs ${item.建议标签 === '推荐' ? 'bg-green-100 text-green-700' : item.建议标签 === '可观察' ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'}`}>
                    {item.建议标签}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {profitData.length === 0 && <div className="p-8 text-center text-slate-500">暂无利润数据（需要同时有Temu核价和商家报价）</div>}
      </div>
    </div>
  );
}