import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const merchant = await prisma.merchant.findUnique({
      where: { id: parseInt(params.id) },
      include: { market: true },
    });
    if (!merchant) return NextResponse.json({ error: "商家不存在" }, { status: 404 });
    return NextResponse.json(merchant);
  } catch {
    return NextResponse.json({ error: "获取失败" }, { status: 500 });
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await request.json();
    const { boothCode, boothLocation, merchantName, contactName, wechat, qq, phone, mainCategory, remark } = body;
    
    const existing = await prisma.merchant.findUnique({ where: { id: parseInt(params.id) } });
    if (!existing) return NextResponse.json({ error: "商家不存在" }, { status: 404 });
    
    const merchant = await prisma.merchant.update({
      where: { id: parseInt(params.id) },
      data: { boothCode, boothLocation, merchantName, contactName, wechat, qq, phone, mainCategory, remark },
    });
    return NextResponse.json(merchant);
  } catch {
    return NextResponse.json({ error: "更新失败" }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await prisma.merchant.delete({ where: { id: parseInt(params.id) } });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "删除失败" }, { status: 500 });
  }
}