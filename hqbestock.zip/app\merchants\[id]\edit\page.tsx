"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, Loader2 } from "lucide-react";

interface MerchantData {
  id: number;
  boothCode: string;
  boothLocation: string;
  merchantName: string;
  contactName: string;
  wechat: string;
  qq: string;
  phone: string;
  mainCategory: string;
  remark: string;
  market: { id: number; name: string };
}

export default function EditMerchantPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [merchant, setMerchant] = useState<MerchantData | null>(null);
  
  const [form, setForm] = useState({
    boothCode: "",
    boothLocation: "",
    merchantName: "",
    contactName: "",
    wechat: "",
    qq: "",
    phone: "",
    mainCategory: "",
    remark: "",
  });

  useEffect(() => {
    fetch(`/api/merchants/${params.id}`)
      .then(res => {
        if (!res.ok) throw new Error("商家不存在");
        return res.json();
      })
      .then(data => {
        setMerchant(data);
        setForm({
          boothCode: data.boothCode || "",
          boothLocation: data.boothLocation || "",
          merchantName: data.merchantName || "",
          contactName: data.contactName || "",
          wechat: data.wechat || "",
          qq: data.qq || "",
          phone: data.phone || "",
          mainCategory: data.mainCategory || "",
          remark: data.remark || "",
        });
        setLoading(false);
      })
      .catch(() => {
        alert("商家不存在");
        router.push("/merchants");
      });
  }, [params.id, router]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch(`/api/merchants/${params.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (res.ok) {
        alert("商家更新成功！");
        router.push("/merchants");
      } else {
        const err = await res.json();
        alert("更新失败: " + (err.error || "未知错误"));
      }
    } catch {
      alert("更新失败: 网络错误");
    }
    setSubmitting(false);
  };

  if (loading) return <div className="p-8 text-center text-slate-500">加载中...</div>;
  if (!merchant) return <div className="p-8 text-center text-slate-500">商家不存在</div>;

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <div className="flex items-center gap-4">
        <Link href="/merchants" className="p-2 hover:bg-slate-100 rounded">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <h1 className="text-2xl font-bold text-slate-800">✏️ 编辑商家</h1>
      </div>

      <div className="bg-slate-100 rounded-xl p-4">
        <div className="text-sm text-slate-500 mb-2">所属市场 (不可修改)</div>
        <div className="text-lg font-medium text-slate-800">{merchant.market.name}</div>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-xl border p-6 space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">档口号 <span className="text-red-500">*</span></label>
            <input required value={form.boothCode} onChange={e => setForm({...form, boothCode: e.target.value})} className="w-full border rounded-lg px-3 py-2" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">档口位置</label>
            <input value={form.boothLocation} onChange={e => setForm({...form, boothLocation: e.target.value})} className="w-full border rounded-lg px-3 py-2" />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">商家名称 <span className="text-red-500">*</span></label>
          <input required value={form.merchantName} onChange={e => setForm({...form, merchantName: e.target.value})} className="w-full border rounded-lg px-3 py-2" />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">联系人</label>
            <input value={form.contactName} onChange={e => setForm({...form, contactName: e.target.value})} className="w-full border rounded-lg px-3 py-2" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">电话</label>
            <input value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} className="w-full border rounded-lg px-3 py-2" />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">微信</label>
            <input value={form.wechat} onChange={e => setForm({...form, wechat: e.target.value})} className="w-full border rounded-lg px-3 py-2" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">QQ</label>
            <input value={form.qq} onChange={e => setForm({...form, qq: e.target.value})} className="w-full border rounded-lg px-3 py-2" />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">主营品类</label>
          <input value={form.mainCategory} onChange={e => setForm({...form, mainCategory: e.target.value})} placeholder="如 手机壳、充电器" className="w-full border rounded-lg px-3 py-2" />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">备注</label>
          <textarea value={form.remark} onChange={e => setForm({...form, remark: e.target.value})} rows={3} className="w-full border rounded-lg px-3 py-2" />
        </div>

        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 text-sm text-yellow-800">
          ℹ️ 注意：市场不可修改。如需修改市场，请删除后重新创建商家。
        </div>

        <div className="flex gap-4 pt-4">
          <button type="submit" disabled={submitting} className="flex-1 bg-slate-900 text-white py-2 rounded-lg hover:bg-slate-800 disabled:opacity-50 flex items-center justify-center gap-2">
            {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
            {submitting ? "保存中..." : "保存修改"}
          </button>
          <Link href="/merchants" className="px-6 py-2 border rounded-lg hover:bg-slate-50">取消</Link>
        </div>
      </form>
    </div>
  );
}