"use client";
import { useState, useEffect } from "react";
import { Plus, Search, Edit, Trash2, X } from "lucide-react";

interface Product {
  id: number;
  skuCode: string;
  category: { name: string };
  deviceModel: { name: string };
  color: { name: string };
}

interface Pricing {
  id: number;
  productId: number;
  temuPrice: number;
  status: string;
  pricingDate: string;
  product: Product;
}

export default function PricingPage() {
  const [pricings, setPricings] = useState<Pricing[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  
  const [form, setForm] = useState({
    productId: "",
    temuPrice: "",
    status: "pending",
  });

  // 加载数据
  useEffect(() => {
    Promise.all([
      fetch("/api/pricing").then(r => r.json()),
      fetch("/api/products").then(r => r.json()),
    ]).then(([pricingsData, productsData]) => {
      setPricings(pricingsData);
      setProducts(productsData);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  // 过滤
  const filteredPricings = pricings.filter(p => {
    if (search && !p.product.skuCode.toLowerCase().includes(search.toLowerCase())) return false;
    if (statusFilter && p.status !== statusFilter) return false;
    return true;
  });

  const statusMap: Record<string, string> = { approved: "已通过", rejected: "已拒绝", pending: "待审核" };

  // 新增核价
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.productId || !form.temuPrice) {
      alert("请选择商品并填写核价");
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/pricing", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productId: parseInt(form.productId),
          temuPrice: parseFloat(form.temuPrice),
          status: form.status,
        }),
      });
      if (res.ok) {
        const newPricing = await res.json();
        // 重新加载
        const updated = await fetch("/api/pricing").then(r => r.json());
        setPricings(updated);
        setShowModal(false);
        setForm({ productId: "", temuPrice: "", status: "pending" });
        alert("核价记录创建成功！");
      } else {
        alert("创建失败");
      }
    } catch { alert("创建失败"); }
    setSubmitting(false);
  };

  // 删除核价
  const handleDelete = async (id: number) => {
    if (!confirm("确定删除这条核价记录？")) return;
    try {
      const res = await fetch(`/api/pricing?id=${id}`, { method: "DELETE" });
      if (res.ok) {
        setPricings(pricings.filter(p => p.id !== id));
        alert("删除成功");
      } else {
        alert("删除失败");
      }
    } catch { alert("删除失败"); }
  };

  // 已选择过核价的商品ID
  const pricedProductIds = new Set(pricings.map(p => p.productId));
  const availableProducts = products.filter(p => !pricedProductIds.has(p.id));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-800">📈 Temu核价记录</h1>
        <button onClick={() => setShowModal(true)} className="flex items-center gap-2 bg-slate-900 text-white px-4 py-2 rounded-lg hover:bg-slate-800">
          <Plus className="w-4 h-4" /> 新增核价
        </button>
      </div>

      {/* 搜索筛选 */}
      <div className="bg-white rounded-xl border p-4">
        <div className="flex gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="搜索SKU..." className="w-full pl-10 pr-4 py-2 border rounded-lg" />
          </div>
          <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="border rounded-lg px-4 py-2">
            <option value="">全部状态</option>
            <option value="approved">已通过</option>
            <option value="rejected">已拒绝</option>
            <option value="pending">待审核</option>
          </select>
        </div>
      </div>

      {/* 列表 */}
      <div className="bg-white rounded-xl border overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50 border-b">
            <tr>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">SKU</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">商品信息</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">核价</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">状态</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">核价日期</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">操作</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {filteredPricings.map((p) => (
              <tr key={p.id} className="hover:bg-slate-50">
                <td className="p-3"><code className="text-xs bg-slate-100 px-2 py-1 rounded">{p.product.skuCode}</code></td>
                <td className="p-3 text-sm">{p.product.category.name} | {p.product.deviceModel.name} | {p.product.color.name}</td>
                <td className="p-3 font-bold text-orange-600">¥{p.temuPrice}</td>
                <td className="p-3"><span className={`px-2 py-1 rounded text-xs ${p.status === 'approved' ? 'bg-green-100 text-green-700' : p.status === 'rejected' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'}`}>{statusMap[p.status]}</span></td>
                <td className="p-3 text-sm text-slate-500">{new Date(p.pricingDate).toLocaleDateString("zh-CN")}</td>
                <td className="p-3">
                  <button onClick={() => handleDelete(p.id)} className="p-2 hover:bg-red-50 rounded text-red-600"><Trash2 className="w-4 h-4" /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredPricings.length === 0 && <div className="p-8 text-center text-slate-500">暂无核价数据</div>}
      </div>

      {/* 新增弹窗 */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold">新增核价</h2>
              <button onClick={() => setShowModal(false)} className="p-2 hover:bg-slate-100 rounded"><X className="w-5 h-5" /></button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">选择商品 <span className="text-red-500">*</span></label>
                <select required value={form.productId} onChange={e => setForm({...form, productId: e.target.value})} className="w-full border rounded-lg px-3 py-2">
                  <option value="">选择商品</option>
                  {availableProducts.map(p => <option key={p.id} value={p.id}>{p.skuCode} - {p.category.name} {p.deviceModel.name}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Temu核价 <span className="text-red-500">*</span></label>
                <input required type="number" step="0.01" value={form.temuPrice} onChange={e => setForm({...form, temuPrice: e.target.value})} placeholder="输入核价金额" className="w-full border rounded-lg px-3 py-2" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">状态</label>
                <select value={form.status} onChange={e => setForm({...form, status: e.target.value})} className="w-full border rounded-lg px-3 py-2">
                  <option value="pending">待审核</option>
                  <option value="approved">已通过</option>
                  <option value="rejected">已拒绝</option>
                </select>
              </div>
              <div className="flex gap-4 pt-2">
                <button type="submit" disabled={submitting} className="flex-1 bg-slate-900 text-white py-2 rounded-lg hover:bg-slate-800 disabled:opacity-50">
                  {submitting ? "保存中..." : "保存"}
                </button>
                <button type="button" onClick={() => setShowModal(false)} className="px-6 py-2 border rounded-lg hover:bg-slate-50">取消</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}