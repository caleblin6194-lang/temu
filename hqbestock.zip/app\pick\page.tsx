"use client";
import { useState } from "react";
import { Search, Package, MapPin, Smartphone } from "lucide-react";

interface Product {
  id: number;
  skuCode: string;
  category: { name: string };
  series: { name: string };
  deviceModel: { name: string; code: string };
  color: { name: string };
  merchant: { market: { name: string }; boothCode: string; merchantName: string };
  pickTasks: { quantity: number; status: string }[];
}

export default function PickPage() {
  const [search, setSearch] = useState("");
  const [result, setResult] = useState<Product | null>(null);

  // Mock 数据
  const mockProducts: Product[] = [
    { id: 1, skuCode: "SG-A12-SK-CX-IP15PM-H-001", category: { name: "手机壳" }, series: { name: "磁吸" }, deviceModel: { name: "iPhone 15 Pro Max", code: "IP15PM" }, color: { name: "黑" }, merchant: { market: { name: "赛格广场" }, boothCode: "A12", merchantName: "华强精品壳王" }, pickTasks: [{ quantity: 50, status: "pending" }] },
    { id: 2, skuCode: "SG-A12-SK-CX-IP15PM-B-002", category: { name: "手机壳" }, series: { name: "磁吸" }, deviceModel: { name: "iPhone 15 Pro Max", code: "IP15PM" }, color: { name: "白" }, merchant: { market: { name: "赛格广场" }, boothCode: "A12", merchantName: "华强精品壳王" }, pickTasks: [{ quantity: 30, status: "pending" }] },
    { id: 3, skuCode: "HQB-C01-GM-TM-IP14PM-T-001", category: { name: "钢化膜" }, series: { name: "透明" }, deviceModel: { name: "iPhone 14 Pro Max", code: "IP14PM" }, color: { name: "透明" }, merchant: { market: { name: "华强北电子城" }, boothCode: "C01", merchantName: "诚信电子" }, pickTasks: [{ quantity: 80, status: "pending" }] },
    { id: 4, skuCode: "SYB-E22-SK-PW-SS24U-G-001", category: { name: "手机壳" }, series: { name: "皮纹" }, deviceModel: { name: "Samsung S24 Ultra", code: "SS24U" }, color: { name: "绿" }, merchant: { market: { name: "赛博" }, boothCode: "E22", merchantName: "赛博精品配件" }, pickTasks: [{ quantity: 20, status: "pending" }] },
  ];

  const handleSearch = () => {
    const found = mockProducts.find(p => p.skuCode.toLowerCase() === search.toLowerCase());
    setResult(found || null);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") handleSearch();
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-slate-800">📦 档口配货 - 员工视图</h1>

      {/* 搜索框 - 大字适合扫码枪 */}
      <div className="bg-white rounded-xl border p-6">
        <div className="flex gap-4">
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            onKeyDown={handleKeyPress}
            placeholder="输入SKU编码或扫码..."
            className="flex-1 text-lg border-2 border-slate-200 rounded-lg px-4 py-3 focus:border-blue-500 focus:outline-none"
          />
          <button onClick={handleSearch} className="bg-slate-900 text-white px-8 py-3 rounded-lg text-lg font-medium hover:bg-slate-800">
            查询
          </button>
        </div>
      </div>

      {/* 查询结果 */}
      {result && (
        <div className="bg-white rounded-xl border-2 border-blue-200 p-6">
          <div className="text-center mb-6">
            <div className="text-3xl font-bold text-blue-600 mb-2">
              {result.pickTasks[0]?.quantity || 0} 件
            </div>
            <div className="text-slate-500">待配货数量</div>
          </div>

          <div className="grid grid-cols-2 gap-4 text-lg">
            <div className="bg-slate-50 p-4 rounded-lg">
              <div className="text-sm text-slate-500 mb-1">商品简称</div>
              <div className="font-bold text-orange-600">{result.series.name}壳｜{result.deviceModel.code.replace('IP','').replace('PM','PM').replace('P','P')}｜{result.color.name}</div>
            </div>
            <div className="bg-slate-50 p-4 rounded-lg">
              <div className="text-sm text-slate-500 mb-1">SKU编码</div>
              <div className="font-mono font-bold">{result.skuCode}</div>
            </div>
            <div className="bg-slate-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 text-sm text-slate-500 mb-1"><MapPin className="w-4 h-4" />档口位置</div>
              <div className="font-medium">{result.merchant.market.name} {result.merchant.boothCode}档口</div>
            </div>
            <div className="bg-slate-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 text-sm text-slate-500 mb-1"><Smartphone className="w-4 h-4" />商家</div>
              <div className="font-medium">{result.merchant.merchantName}</div>
            </div>
          </div>

          <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <div className="text-sm text-yellow-800">
              <strong>配货说明：</strong>请到 {result.merchant.market.name} {result.merchant.boothCode}档口 "{result.merchant.merchantName}" 拿货 {result.pickTasks[0]?.quantity || 0} 件 {result.category.name} {result.series.name} {result.deviceModel.name} {result.color.name}色
            </div>
          </div>
        </div>
      )}

      {!result && search && (
        <div className="bg-white rounded-xl border p-8 text-center">
          <Package className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <div className="text-lg text-slate-600">未找到商品</div>
          <div className="text-sm text-slate-500 mt-1">请检查SKU编码是否正确</div>
        </div>
      )}

      {/* 底部提示 */}
      <div className="bg-slate-100 rounded-xl p-4 text-center text-sm text-slate-500">
        💡 提示：支持扫码枪扫描SKU条码或手动输入编码查询
      </div>
    </div>
  );
}