import prisma from "@/lib/prisma";
import { Plus, Search, Edit, Trash2 } from "lucide-react";
import Link from "next/link";

export default async function MerchantsPage({ searchParams }: { searchParams: { q?: string; market?: string } }) {
  const { q, market } = searchParams;
  const where: any = {};
  if (q) where.OR = [{ merchantName: { contains: q } }, { contactName: { contains: q } }, { boothCode: { contains: q } }];
  if (market) where.marketId = parseInt(market);

  const [merchants, markets] = await Promise.all([
    prisma.merchant.findMany({ where, include: { market: true }, orderBy: { createdAt: "desc" } }),
    prisma.market.findMany(),
  ]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-800">🏪 商家管理</h1>
        <Link href="/merchants/new" className="flex items-center gap-2 bg-slate-900 text-white px-4 py-2 rounded-lg hover:bg-slate-800">
          <Plus className="w-4 h-4" /> 新增商家
        </Link>
      </div>

      <div className="bg-white rounded-xl border p-4">
        <form className="flex gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input name="q" defaultValue={q} placeholder="搜索商家名称、联系人、档口号..." className="w-full pl-10 pr-4 py-2 border rounded-lg" />
          </div>
          <select name="market" defaultValue={market} className="border rounded-lg px-4 py-2">
            <option value="">全部市场</option>
            {markets.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
          </select>
          <button type="submit" className="bg-slate-100 px-4 py-2 rounded-lg hover:bg-slate-200">搜索</button>
        </form>
      </div>

      <div className="bg-white rounded-xl border overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50 border-b">
            <tr>
              <th className="text-left p-4 font-medium text-slate-600">市场</th>
              <th className="text-left p-4 font-medium text-slate-600">档口号</th>
              <th className="text-left p-4 font-medium text-slate-600">商家名称</th>
              <th className="text-left p-4 font-medium text-slate-600">联系人</th>
              <th className="text-left p-4 font-medium text-slate-600">联系方式</th>
              <th className="text-left p-4 font-medium text-slate-600">主营品类</th>
              <th className="text-left p-4 font-medium text-slate-600">操作</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {merchants.map((m) => (
              <tr key={m.id} className="hover:bg-slate-50">
                <td className="p-4">{m.market.name}</td>
                <td className="p-4">{m.boothCode}</td>
                <td className="p-4 font-medium">{m.merchantName}</td>
                <td className="p-4">{m.contactName || "-"}</td>
                <td className="p-4 text-sm">
                  <div>微信: {m.wechat || "-"}</div>
                  <div>QQ: {m.qq || "-"}</div>
                </td>
                <td className="p-4">{m.mainCategory || "-"}</td>
                <td className="p-4">
                  <div className="flex gap-2">
                    <Link href={`/merchants/${m.id}/edit`} className="p-2 hover:bg-slate-100 rounded">
                      <Edit className="w-4 h-4 text-blue-600" />
                    </Link>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {merchants.length === 0 && <div className="p-8 text-center text-slate-500">暂无商家数据</div>}
      </div>
    </div>
  );
}