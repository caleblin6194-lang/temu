"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, Loader2 } from "lucide-react";

interface ProductData {
  id: number;
  skuCode: string;
  note: string;
  imageUrl: string;
  merchant: { market: { name: string }; boothCode: string; merchantName: string };
  category: { name: string };
  series: { name: string };
  deviceModel: { name: string };
  color: { name: string };
}

export default function EditProductPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [product, setProduct] = useState<ProductData | null>(null);
  
  const [form, setForm] = useState({
    note: "",
    imageUrl: "",
  });

  useEffect(() => {
    fetch(`/api/products/${params.id}`)
      .then(res => {
        if (!res.ok) throw new Error("商品不存在");
        return res.json();
      })
      .then(data => {
        setProduct(data);
        setForm({
          note: data.note || "",
          imageUrl: data.imageUrl || "",
        });
        setLoading(false);
      })
      .catch(() => {
        alert("商品不存在");
        router.push("/products");
      });
  }, [params.id, router]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch(`/api/products/${params.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          note: form.note,
          imageUrl: form.imageUrl,
        }),
      });
      if (res.ok) {
        alert("商品更新成功！");
        router.push(`/products/${params.id}`);
      } else {
        const err = await res.json();
        alert("更新失败: " + (err.error || "未知错误"));
      }
    } catch {
      alert("更新失败: 网络错误");
    }
    setSubmitting(false);
  };

  if (loading) return <div className="p-8 text-center text-slate-500">加载中...</div>;
  if (!product) return <div className="p-8 text-center text-slate-500">商品不存在</div>;

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <div className="flex items-center gap-4">
        <Link href={`/products/${params.id}`} className="p-2 hover:bg-slate-100 rounded">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <h1 className="text-2xl font-bold text-slate-800">✏️ 编辑商品</h1>
      </div>

      <div className="bg-slate-100 rounded-xl p-4">
        <div className="text-sm text-slate-500 mb-2">SKU编码 (不可修改)</div>
        <div className="text-xl font-mono font-bold text-slate-800">{product.skuCode}</div>
        <div className="mt-2 text-sm text-slate-600">
          {product.merchant.market.name} {product.merchant.boothCode}档口 | {product.category.name} | {product.series.name} | {product.deviceModel.name} | {product.color.name}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-xl border p-6 space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">商品图片URL</label>
          <input 
            value={form.imageUrl} 
            onChange={e => setForm({...form, imageUrl: e.target.value})} 
            placeholder="图片URL地址" 
            className="w-full border rounded-lg px-3 py-2" 
          />
          {form.imageUrl && (
            <div className="mt-2">
              <img src={form.imageUrl} alt="预览" className="w-32 h-32 object-cover rounded-lg border" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
            </div>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">备注</label>
          <textarea 
            value={form.note} 
            onChange={e => setForm({...form, note: e.target.value})} 
            rows={4} 
            placeholder="商品备注信息" 
            className="w-full border rounded-lg px-3 py-2" 
          />
        </div>

        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 text-sm text-yellow-800">
          ℹ️ 注意：SKU编码由系统自动生成，商家、品类、系列、型号、颜色、序号均不可修改。如需修改请删除后重新创建。
        </div>

        <div className="flex gap-4 pt-4">
          <button type="submit" disabled={submitting} className="flex-1 bg-slate-900 text-white py-2 rounded-lg hover:bg-slate-800 disabled:opacity-50 flex items-center justify-center gap-2">
            {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
            {submitting ? "保存中..." : "保存修改"}
          </button>
          <Link href={`/products/${params.id}`} className="px-6 py-2 border rounded-lg hover:bg-slate-50">取消</Link>
        </div>
      </form>
    </div>
  );
}