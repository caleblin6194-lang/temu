import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { generateSkuByIds } from "@/lib/sku";

// 获取商品列表
export async function GET() {
  try {
    const products = await prisma.product.findMany({
      include: {
        merchant: { include: { market: true } },
        category: true, series: true, deviceModel: true, color: true,
      },
      orderBy: { createdAt: "desc" },
      take: 100,
    });
    return NextResponse.json(products);
  } catch (error) {
    return NextResponse.json({ error: "获取失败" }, { status: 500 });
  }
}

// 创建商品
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { merchantId, categoryId, seriesId, deviceModelId, colorId, note } = body;

    // 生成SKU
    const market = await prisma.market.findFirst({ where: { merchants: { some: { id: merchantId } } } });
    const merchant = await prisma.merchant.findUnique({ where: { id: merchantId } });
    const category = await prisma.category.findUnique({ where: { id: categoryId } });
    const series = await prisma.series.findUnique({ where: { id: seriesId } });
    const model = await prisma.deviceModel.findUnique({ where: { id: deviceModelId } });
    const color = await prisma.color.findUnique({ where: { id: colorId } });

    if (!market || !merchant || !category || !series || !model || !color) {
      return NextResponse.json({ error: "参数无效" }, { status: 400 });
    }

    // 查询同组合下最大序号
    const baseCode = `${market.code}-${merchant.boothCode}-${category.code}-${series.code}-${model.code}-${color.code}`;
    const lastProduct = await prisma.product.findFirst({
      where: { skuCode: { startsWith: baseCode } },
      orderBy: { serialNo: "desc" },
    });
    const serialNo = lastProduct ? lastProduct.serialNo + 1 : 1;
    const skuCode = `${baseCode}-${String(serialNo).padStart(3, "0")}`;

    const product = await prisma.product.create({
      data: {
        merchantId, categoryId, seriesId, deviceModelId, colorId,
        skuCode, serialNo, note, imageUrl: "/uploads/placeholder.png",
      },
    });

    return NextResponse.json(product);
  } catch (error) {
    return NextResponse.json({ error: "创建失败" }, { status: 500 });
  }
}