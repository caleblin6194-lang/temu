import prisma from "@/lib/prisma";
import { calculateProfit } from "@/lib/sku";
import Link from "next/link";
import { ArrowLeft, Printer, Edit } from "lucide-react";
import Barcode from "@/components/Barcode";
import QRCode from "@/components/QRCode";

export default async function ProductDetail({ params }: { params: { id: string } }) {
  const product = await prisma.product.findUnique({
    where: { id: parseInt(params.id) },
    include: {
      merchant: { include: { market: true } },
      category: true, series: true, deviceModel: true, color: true,
      temuPricing: true,
      quotes: { include: { merchant: true } },
      pickTasks: true,
    },
  });

  if (!product) return <div className="p-8">商品不存在</div>;

  // 中文翻译 - 完整版
  const chineseTranslation = `${product.merchant.market.name} ${product.merchant.boothCode}档口｜${product.category.name}｜${product.series.name}｜${product.deviceModel.name}｜${product.color.name}色｜${String(product.serialNo).padStart(3, '0')}`;

  // 短标签
  const shortModel = product.deviceModel.code
    .replace('IP15PM', '15PM')
    .replace('IP15P', '15P')
    .replace('IP15', '15')
    .replace('IP14PM', '14PM')
    .replace('IP14P', '14P')
    .replace('IP14', '14')
    .replace('SS24U', 'S24U')
    .replace('SS24P', 'S24+')
    .replace('SS24', 'S24')
    .replace('XM14', 'XM14');
  const shortLabel = `${product.series.name}壳｜${shortModel}｜${product.color.name}`;

  // 利润计算
  const temuPrice = product.temuPricing?.temuPrice || 0;
  const quote = product.quotes[0];
  const supplierPrice = quote?.supplierPrice || 0;
  const logisticsCost = quote?.logisticsCost || 0;
  const platformFee = quote?.platformFee || 0;
  const extraCost = quote?.extraCost || 0;
  const profitResult = calculateProfit({ temuPrice, supplierPrice, logisticsCost, platformFee, extraCost });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/products" className="p-2 hover:bg-slate-100 rounded"><ArrowLeft className="w-5 h-5" /></Link>
          <h1 className="text-2xl font-bold text-slate-800">商品详情</h1>
        </div>
        <Link href={`/products/${product.id}/edit`} className="flex items-center gap-2 bg-slate-100 px-4 py-2 rounded-lg hover:bg-slate-200">
          <Edit className="w-4 h-4" /> 编辑商品
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* 基本信息 */}
        <div className="md:col-span-2 bg-white rounded-xl border p-6 space-y-4">
          <div>
            <label className="text-sm text-slate-500">SKU编码</label>
            <p className="text-xl font-mono font-bold text-slate-800">{product.skuCode}</p>
          </div>
          
          {/* 中文翻译 */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <label className="text-sm text-blue-600 font-medium">📖 中文翻译</label>
            <p className="text-lg font-bold text-blue-800 mt-1">{chineseTranslation}</p>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div><label className="text-sm text-slate-500">市场</label><p className="font-medium">{product.merchant.market.name}</p></div>
            <div><label className="text-sm text-slate-500">档口号</label><p className="font-medium">{product.merchant.boothCode}</p></div>
            <div><label className="text-sm text-slate-500">商家</label><p className="font-medium">{product.merchant.merchantName}</p></div>
            <div><label className="text-sm text-slate-500">品类</label><p className="font-medium">{product.category.name}</p></div>
            <div><label className="text-sm text-slate-500">系列</label><p className="font-medium">{product.series.name}</p></div>
            <div><label className="text-sm text-slate-500">型号</label><p className="font-medium">{product.deviceModel.name}</p></div>
            <div><label className="text-sm text-slate-500">颜色</label><p className="font-medium">{product.color.name}</p></div>
            <div><label className="text-sm text-slate-500">序号</label><p className="font-medium">{String(product.serialNo).padStart(3, '0')}</p></div>
          </div>
          
          {/* 短标签 */}
          <div><label className="text-sm text-slate-500">短标签</label><p className="font-bold text-orange-600 text-lg">{shortLabel}</p></div>
          
          {product.note && <div><label className="text-sm text-slate-500">备注</label><p className="text-slate-600">{product.note}</p></div>}
        </div>

        {/* 图片+条码+二维码 */}
        <div className="bg-white rounded-xl border p-6 space-y-4">
          <div>
            <label className="text-sm text-slate-500">商品图片</label>
            <div className="mt-2 aspect-square bg-slate-100 rounded-lg flex items-center justify-center text-slate-400 overflow-hidden">
              {product.imageUrl ? (
                <img src={product.imageUrl} alt="商品图" className="w-full h-full object-cover" />
              ) : (
                <span>暂无图片</span>
              )}
            </div>
          </div>
          
          <div>
            <label className="text-sm text-slate-500">条码 (Code128)</label>
            <div className="mt-2 p-2 bg-white border rounded-lg flex justify-center">
              <Barcode value={product.skuCode} width={2} height={50} />
            </div>
          </div>
          
          <div>
            <label className="text-sm text-slate-500">二维码</label>
            <div className="mt-2 p-2 bg-white border rounded-lg flex justify-center">
              <QRCode value={`http://localhost:3000/products/${product.id}`} size={100} />
            </div>
          </div>
          
          <Link href={`/print?sku=${product.skuCode}`} className="flex items-center justify-center gap-2 w-full bg-red-600 text-white py-2 rounded-lg hover:bg-red-700">
            <Printer className="w-4 h-4" /> 打印标签
          </Link>
        </div>
      </div>

      {/* 定价与利润 */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border p-6">
          <h3 className="font-semibold mb-4">💰 Temu核价</h3>
          {product.temuPricing ? (
            <div className="space-y-2">
              <div className="flex justify-between"><span className="text-slate-500">核价</span><span className="font-bold text-orange-600">¥{product.temuPricing.temuPrice}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">状态</span><span className={`px-2 py-1 rounded text-xs ${product.temuPricing.status === 'approved' ? 'bg-green-100 text-green-700' : product.temuPricing.status === 'rejected' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'}`}>{product.temuPricing.status === 'approved' ? '已通过' : product.temuPricing.status === 'rejected' ? '已拒绝' : '待审核'}</span></div>
            </div>
          ) : <p className="text-slate-500">暂无核价记录 - 请到Temu核价页面添加</p>}
        </div>

        <div className="bg-white rounded-xl border p-6">
          <h3 className="font-semibold mb-4">📊 利润分析</h3>
          {quote ? (
            <div className="space-y-2">
              <div className="flex justify-between"><span className="text-slate-500">Temu核价</span><span>¥{temuPrice}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">供货价</span><span className="text-red-500">-¥{supplierPrice}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">物流</span><span className="text-red-500">-¥{logisticsCost}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">平台费</span><span className="text-red-500">-¥{platformFee}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">其他</span><span className="text-red-500">-¥{extraCost}</span></div>
              <div className="border-t pt-2 flex justify-between"><span className="font-bold">预估利润</span><span className={`font-bold text-xl ${profitResult.预估利润 > 0 ? 'text-green-600' : 'text-red-600'}`}>¥{profitResult.预估利润}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">利润率</span><span className="font-bold text-lg">{profitResult.利润率}%</span></div>
              <div className="mt-2">
                <span className={`px-4 py-2 rounded-full text-sm font-medium ${profitResult.建议标签 === '推荐' ? 'bg-green-100 text-green-700' : profitResult.建议标签 === '可观察' ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'}`}>
                  【{profitResult.建议标签}】
                </span>
              </div>
            </div>
          ) : <p className="text-slate-500">暂无报价记录 - 请到商家报价页面添加</p>}
        </div>
      </div>

      {/* 配货信息 */}
      <div className="bg-white rounded-xl border p-6">
        <h3 className="font-semibold mb-4">📦 配货任务</h3>
        {product.pickTasks.length > 0 ? (
          <div className="space-y-2">
            {product.pickTasks.map((task) => (
              <div key={task.id} className="flex justify-between items-center">
                <span>待配数量: <span className="font-bold text-lg">{task.quantity}</span></span>
                <span className={`px-3 py-1 rounded text-sm ${task.status === 'completed' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>{task.status === 'completed' ? '已完成' : '待配货'}</span>
              </div>
            ))}
          </div>
        ) : <p className="text-slate-500">暂无配货任务</p>}
      </div>
    </div>
  );
}