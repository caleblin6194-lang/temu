"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, Loader2 } from "lucide-react";

interface Market {
  id: number;
  code: string;
  name: string;
}

export default function NewMerchantPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [markets, setMarkets] = useState<Market[]>([]);
  
  const [form, setForm] = useState({
    marketId: "",
    boothCode: "",
    boothLocation: "",
    merchantName: "",
    contactName: "",
    wechat: "",
    qq: "",
    phone: "",
    mainCategory: "",
    remark: "",
  });

  // 从API加载市场数据
  useEffect(() => {
    fetch("/api/dicts?type=markets")
      .then(r => r.json())
      .then(data => setMarkets(data))
      .catch(() => {
        // 备用数据
        setMarkets([
          { id: 1, code: "SG", name: "赛格广场" },
          { id: 2, code: "HQB", name: "华强北电子城" },
          { id: 3, code: "SYB", name: "赛博" },
          { id: 4, code: "YHD", name: "远望数码城" },
        ]);
      });
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch("/api/merchants", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          ...form, 
          marketId: parseInt(form.marketId) 
        }),
      });
      if (res.ok) {
        const merchant = await res.json();
        alert(`商家创建成功！`);
        router.push("/merchants");
      } else {
        const err = await res.json();
        alert("创建失败: " + (err.error || "未知错误"));
      }
    } catch (error) {
      alert("创建失败: 网络错误");
    }
    setLoading(false);
  };

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <div className="flex items-center gap-4">
        <Link href="/merchants" className="p-2 hover:bg-slate-100 rounded"><ArrowLeft className="w-5 h-5" /></Link>
        <h1 className="text-2xl font-bold text-slate-800">➕ 新增商家</h1>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-xl border p-6 space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">市场 <span className="text-red-500">*</span></label>
            <select required value={form.marketId} onChange={e => setForm({...form, marketId: e.target.value})} className="w-full border rounded-lg px-3 py-2">
              <option value="">请选择市场</option>
              {markets.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">档口号 <span className="text-red-500">*</span></label>
            <input required value={form.boothCode} onChange={e => setForm({...form, boothCode: e.target.value})} placeholder="如 A12, B08" className="w-full border rounded-lg px-3 py-2" />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">档口位置</label>
          <input value={form.boothLocation} onChange={e => setForm({...form, boothLocation: e.target.value})} placeholder="如 赛格广场3楼3A012" className="w-full border rounded-lg px-3 py-2" />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">商家名称 <span className="text-red-500">*</span></label>
          <input required value={form.merchantName} onChange={e => setForm({...form, merchantName: e.target.value})} placeholder="商家名称" className="w-full border rounded-lg px-3 py-2" />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">联系人</label>
            <input value={form.contactName} onChange={e => setForm({...form, contactName: e.target.value})} placeholder="联系人姓名" className="w-full border rounded-lg px-3 py-2" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">电话</label>
            <input value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} placeholder="手机号" className="w-full border rounded-lg px-3 py-2" />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">微信</label>
            <input value={form.wechat} onChange={e => setForm({...form, wechat: e.target.value})} placeholder="微信号" className="w-full border rounded-lg px-3 py-2" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">QQ</label>
            <input value={form.qq} onChange={e => setForm({...form, qq: e.target.value})} placeholder="QQ号" className="w-full border rounded-lg px-3 py-2" />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">主营品类</label>
          <input value={form.mainCategory} onChange={e => setForm({...form, mainCategory: e.target.value})} placeholder="如 手机壳、充电器" className="w-full border rounded-lg px-3 py-2" />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">备注</label>
          <textarea value={form.remark} onChange={e => setForm({...form, remark: e.target.value})} rows={3} placeholder="备注信息" className="w-full border rounded-lg px-3 py-2" />
        </div>

        <div className="flex gap-4 pt-4">
          <button type="submit" disabled={loading} className="flex-1 bg-slate-900 text-white py-2 rounded-lg hover:bg-slate-800 disabled:opacity-50 flex items-center justify-center gap-2">
            {loading && <Loader2 className="w-4 h-4 animate-spin" />}
            {loading ? "保存中..." : "保存商家"}
          </button>
          <Link href="/merchants" className="px-6 py-2 border rounded-lg hover:bg-slate-50">取消</Link>
        </div>
      </form>
    </div>
  );
}