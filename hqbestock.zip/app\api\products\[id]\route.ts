import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const product = await prisma.product.findUnique({
      where: { id: parseInt(params.id) },
      include: {
        merchant: { include: { market: true } },
        category: true, series: true, deviceModel: true, color: true,
      },
    });
    if (!product) return NextResponse.json({ error: "商品不存在" }, { status: 404 });
    return NextResponse.json(product);
  } catch {
    return NextResponse.json({ error: "获取失败" }, { status: 500 });
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await request.json();
    const { note, imageUrl } = body;
    
    const existing = await prisma.product.findUnique({ where: { id: parseInt(params.id) } });
    if (!existing) return NextResponse.json({ error: "商品不存在" }, { status: 404 });
    
    const product = await prisma.product.update({
      where: { id: parseInt(params.id) },
      data: { note, imageUrl },
    });
    return NextResponse.json(product);
  } catch {
    return NextResponse.json({ error: "更新失败" }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await prisma.product.delete({ where: { id: parseInt(params.id) } });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "删除失败" }, { status: 500 });
  }
}