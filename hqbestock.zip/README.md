# 华强北跨境选品与档口配货管理系统

> 华强北选品-核价-询价-利润测算-档口配货一体化 Web 系统

## 项目简介

这是一个专为跨境电商设计的全栈管理系统，支持：
- 商家/档口资料管理
- 商品选品与 SKU 自动生成
- Temu 平台核价记录
- 商家报价管理
- 利润自动测算
- 条码/二维码标签打印
- 档口员工配货视图

## 技术栈

- **前端**: Next.js 14 + React + TypeScript
- **样式**: Tailwind CSS
- **后端**: Next.js API Routes
- **数据库**: Prisma ORM + SQLite
- **条码**: JsBarcode

## 安装步骤

```bash
# 1. 进入项目目录
cd hqbestock

# 2. 安装依赖
npm install

# 3. 生成 Prisma Client
npx prisma generate

# 4. 初始化数据库
npx prisma db push

# 5. 导入种子数据
npm run db:seed

# 6. 启动开发服务器
npm run dev
```

## 访问地址

浏览器打开: http://localhost:3000

## SKU 编码规则

```
[市场]-[档口]-[品类]-[系列]-[型号]-[颜色]-[序号]

示例: SG-A12-SK-CX-IP15PM-H-001

市场: SG=赛格广场, HQB=华强北电子城, SYB=赛博, YHD=远望数码城
品类: SK=手机壳, CD=充电器, SX=数据线, GM=钢化膜, EJ=耳机
系列: CX=磁吸, FS=防摔, TM=透明, MS=磨砂, PW=皮纹, CB=超薄
颜色: H=黑, B=白, L=蓝, F=粉, G=绿, T=透明, R=红, GY=灰
```

## 页面清单

| 路径 | 功能 |
|------|------|
| / | 首页/快捷入口 |
| /dashboard | 仪表盘统计 |
| /merchants | 商家列表 |
| /merchants/new | 新增商家 |
| /products | 商品列表 |
| /products/new | 新增商品(自动生成SKU) |
| /products/[id] | 商品详情/条码/利润 |
| /pricing | Temu核价记录 |
| /quotes | 商家报价记录 |
| /profit | 利润分析 |
| /print | 标签打印 |
| /pick | 档口配货视图 |

## 后续扩展

1. **Temu API 对接** - 可接入RPA或官方API
2. **微信/QQ抓取** - 接入微信机器人
3. **扫码枪对接** - 档口配货扫码
4. **仓库流程** - 入库/出库/盘点
5. **对象存储** - S3/R2图片存储

## 许可证

MIT