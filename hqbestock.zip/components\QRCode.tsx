"use client";
import { useEffect, useRef } from "react";
import QRCodeLib from "qrcode";

interface QRCodeProps {
  value: string;
  size?: number;
}

export default function QRCode({ value, size = 100 }: QRCodeProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (canvasRef.current && value) {
      try {
        QRCodeLib.toCanvas(canvasRef.current, value, {
          width: size,
          margin: 2,
        });
      } catch (error) {
        console.error("QRCode generation failed:", error);
      }
    }
  }, [value, size]);

  return <canvas ref={canvasRef}></canvas>;
}