"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, RefreshCw, Loader2 } from "lucide-react";

interface Merchant {
  id: number;
  market: { name: string; code: string };
  boothCode: string;
  merchantName: string;
}

interface Category { id: number; code: string; name: string }
interface Series { id: number; code: string; name: string }
interface DeviceModel { id: number; code: string; name: string }
interface Color { id: number; code: string; name: string }

export default function NewProductPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [skuPreview, setSkuPreview] = useState("");
  
  const [merchants, setMerchants] = useState<Merchant[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [seriesList, setSeriesList] = useState<Series[]>([]);
  const [deviceModels, setDeviceModels] = useState<DeviceModel[]>([]);
  const [colors, setColors] = useState<Color[]>([]);

  const [form, setForm] = useState({
    merchantId: "",
    categoryId: "",
    seriesId: "",
    deviceModelId: "",
    colorId: "",
    note: "",
  });

  // 从API加载字典数据
  useEffect(() => {
    Promise.all([
      fetch("/api/merchants").then(r => r.json()),
      fetch("/api/dicts?type=categories").then(r => r.json()),
      fetch("/api/dicts?type=series").then(r => r.json()),
      fetch("/api/dicts?type=deviceModels").then(r => r.json()),
      fetch("/api/dicts?type=colors").then(r => r.json()),
    ]).then(([merchantsData, categoriesData, seriesData, modelsData, colorsData]) => {
      setMerchants(merchantsData);
      setCategories(categoriesData);
      setSeriesList(seriesData);
      setDeviceModels(modelsData);
      setColors(colorsData);
    }).catch(err => {
      console.error("加载数据失败:", err);
      // 使用备用数据
      setMerchants([
        { id: 1, market: { name: "赛格广场", code: "SG" }, boothCode: "A12", merchantName: "华强精品壳王" },
        { id: 2, market: { name: "赛格广场", code: "SG" }, boothCode: "B08", merchantName: "数码配件批发" },
        { id: 3, market: { name: "华强北电子城", code: "HQB" }, boothCode: "C01", merchantName: "诚信电子" },
      ]);
      setCategories([
        { id: 1, code: "SK", name: "手机壳" },
        { id: 2, code: "CD", name: "充电器" },
        { id: 3, code: "SX", name: "数据线" },
        { id: 4, code: "GM", name: "钢化膜" },
        { id: 5, code: "EJ", name: "耳机" },
      ]);
      setSeriesList([
        { id: 1, code: "CX", name: "磁吸" },
        { id: 2, code: "FS", name: "防摔" },
        { id: 3, code: "TM", name: "透明" },
        { id: 4, code: "MS", name: "磨砂" },
        { id: 5, code: "PW", name: "皮纹" },
        { id: 6, code: "CB", name: "超薄" },
      ]);
      setDeviceModels([
        { id: 1, code: "IP15PM", name: "iPhone 15 Pro Max" },
        { id: 2, code: "IP15P", name: "iPhone 15 Pro" },
        { id: 3, code: "IP15", name: "iPhone 15" },
        { id: 4, code: "IP14PM", name: "iPhone 14 Pro Max" },
        { id: 7, code: "SS24U", name: "Samsung S24 Ultra" },
      ]);
      setColors([
        { id: 1, code: "H", name: "黑" },
        { id: 2, code: "B", name: "白" },
        { id: 3, code: "L", name: "蓝" },
        { id: 4, code: "F", name: "粉" },
        { id: 5, code: "G", name: "绿" },
        { id: 6, code: "T", name: "透明" },
      ]);
    });
  }, []);

  // 实时预览SKU
  useEffect(() => {
    if (!form.merchantId || !form.categoryId || !form.seriesId || !form.deviceModelId || !form.colorId) {
      setSkuPreview("");
      return;
    }
    const merchant = merchants.find(m => m.id === parseInt(form.merchantId));
    const category = categories.find(c => c.id === parseInt(form.categoryId));
    const series = seriesList.find(s => s.id === parseInt(form.seriesId));
    const model = deviceModels.find(d => d.id === parseInt(form.deviceModelId));
    const color = colors.find(c => c.id === parseInt(form.colorId));
    
    if (merchant && category && series && model && color) {
      setSkuPreview(`${merchant.market.code}-${merchant.boothCode}-${category.code}-${series.code}-${model.code}-${color.code}-???`);
    }
  }, [form, merchants, categories, seriesList, deviceModels, colors]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!skuPreview.includes("???")) {
      alert("请选择完整商品信息");
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          merchantId: parseInt(form.merchantId),
          categoryId: parseInt(form.categoryId),
          seriesId: parseInt(form.seriesId),
          deviceModelId: parseInt(form.deviceModelId),
          colorId: parseInt(form.colorId),
          note: form.note,
        }),
      });
      if (res.ok) {
        const product = await res.json();
        alert(`商品创建成功！SKU: ${product.skuCode}`);
        router.push(`/products/${product.id}`);
      } else {
        const err = await res.json();
        alert("创建失败: " + (err.error || "未知错误"));
      }
    } catch (error) {
      alert("创建失败: 网络错误");
    }
    setSubmitting(false);
  };

  const allSelected = form.merchantId && form.categoryId && form.seriesId && form.deviceModelId && form.colorId;

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <div className="flex items-center gap-4">
        <Link href="/products" className="p-2 hover:bg-slate-100 rounded"><ArrowLeft className="w-5 h-5" /></Link>
        <h1 className="text-2xl font-bold text-slate-800">➕ 新增商品</h1>
      </div>

      {skuPreview && (
        <div className="bg-gradient-to-r from-blue-600 to-blue-500 rounded-xl p-4 text-white">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm opacity-80">自动生成的SKU编码</div>
              <div className="text-2xl font-mono font-bold">{skuPreview.replace("???", "<序号>")}</div>
            </div>
            <RefreshCw className="w-6 h-6 opacity-80" />
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="bg-white rounded-xl border p-6 space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">商家/档口 <span className="text-red-500">*</span></label>
            <select required value={form.merchantId} onChange={e => setForm({...form, merchantId: e.target.value})} className="w-full border rounded-lg px-3 py-2">
              <option value="">选择商家</option>
              {merchants.map(m => <option key={m.id} value={m.id}>{m.market.name} {m.boothCode} - {m.merchantName}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">品类 <span className="text-red-500">*</span></label>
            <select required value={form.categoryId} onChange={e => setForm({...form, categoryId: e.target.value})} className="w-full border rounded-lg px-3 py-2">
              <option value="">选择品类</option>
              {categories.map(c => <option key={c.id} value={c.id}>{c.name} ({c.code})</option>)}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">系列 <span className="text-red-500">*</span></label>
            <select required value={form.seriesId} onChange={e => setForm({...form, seriesId: e.target.value})} className="w-full border rounded-lg px-3 py-2">
              <option value="">选择系列</option>
              {seriesList.map(s => <option key={s.id} value={s.id}>{s.name} ({s.code})</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">型号 <span className="text-red-500">*</span></label>
            <select required value={form.deviceModelId} onChange={e => setForm({...form, deviceModelId: e.target.value})} className="w-full border rounded-lg px-3 py-2">
              <option value="">选择型号</option>
              {deviceModels.map(m => <option key={m.id} value={m.id}>{m.name} ({m.code})</option>)}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">颜色 <span className="text-red-500">*</span></label>
            <select required value={form.colorId} onChange={e => setForm({...form, colorId: e.target.value})} className="w-full border rounded-lg px-3 py-2">
              <option value="">选择颜色</option>
              {colors.map(c => <option key={c.id} value={c.id}>{c.name} ({c.code})</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">备注</label>
            <input value={form.note} onChange={e => setForm({...form, note: e.target.value})} placeholder="可选备注" className="w-full border rounded-lg px-3 py-2" />
          </div>
        </div>

        <div className="flex gap-4 pt-4">
          <button type="submit" disabled={submitting || !allSelected} className="flex-1 bg-slate-900 text-white py-2 rounded-lg hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2">
            {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
            {submitting ? "保存中..." : "生成SKU并保存"}
          </button>
          <Link href="/products" className="px-6 py-2 border rounded-lg hover:bg-slate-50">取消</Link>
        </div>
      </form>

      <div className="bg-slate-50 rounded-xl p-4 text-sm">
        <div className="font-medium mb-2">📖 SKU编码规则</div>
        <div className="text-slate-600 space-y-1">
          <div>[市场]-[档口]-[品类]-[系列]-[型号]-[颜色]-[序号]</div>
          <div>示例: SG-A12-SK-CX-IP15PM-H-001</div>
        </div>
      </div>
    </div>
  );
}