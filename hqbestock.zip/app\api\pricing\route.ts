import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";

// 获取核价列表 / 创建核价记录
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");
    const where: any = {};
    if (status) where.status = status;
    
    const pricings = await prisma.temuPricing.findMany({
      where,
      include: { product: { include: { merchant: { include: { market: true } }, category: true, deviceModel: true, color: true } } },
      orderBy: { pricingDate: "desc" },
      take: 100,
    });
    return NextResponse.json(pricings);
  } catch (error) {
    return NextResponse.json({ error: "获取失败" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { productId, temuPrice, status, note } = body;
    
    const pricing = await prisma.temuPricing.upsert({
      where: { productId },
      update: { temuPrice, status, note },
      create: { productId, temuPrice, status: status || "pending", pricingDate: new Date(), note },
    });
    
    return NextResponse.json(pricing);
  } catch (error) {
    return NextResponse.json({ error: "创建失败" }, { status: 500 });
  }
}