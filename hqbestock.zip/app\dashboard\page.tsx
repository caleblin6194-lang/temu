import prisma from "@/lib/prisma";
import { Users, Package, TrendingUp, DollarSign } from "lucide-react";

export default async function Dashboard() {
  const [merchantCount, productCount, pricedCount, recommendedCount] = await Promise.all([
    prisma.merchant.count(),
    prisma.product.count(),
    prisma.temuPricing.count({ where: { status: "approved" } }),
    prisma.product.count({ where: { temuPricing: { status: "approved" } } }),
  ]);

  const recentProducts = await prisma.product.findMany({
    take: 5,
    orderBy: { createdAt: "desc" },
    include: { merchant: { include: { market: true } }, category: true, deviceModel: true },
  });

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-slate-800">📊 仪表盘</h1>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-6 border shadow-sm">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-blue-100 rounded-lg"><Users className="w-6 h-6 text-blue-600" /></div>
            <div>
              <p className="text-2xl font-bold text-slate-800">{merchantCount}</p>
              <p className="text-sm text-slate-500">商家数量</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-6 border shadow-sm">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-green-100 rounded-lg"><Package className="w-6 h-6 text-green-600" /></div>
            <div>
              <p className="text-2xl font-bold text-slate-800">{productCount}</p>
              <p className="text-sm text-slate-500">商品数量</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-6 border shadow-sm">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-orange-100 rounded-lg"><TrendingUp className="w-6 h-6 text-orange-600" /></div>
            <div>
              <p className="text-2xl font-bold text-slate-800">{pricedCount}</p>
              <p className="text-sm text-slate-500">已核价商品</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-6 border shadow-sm">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-purple-100 rounded-lg"><DollarSign className="w-6 h-6 text-purple-600" /></div>
            <div>
              <p className="text-2xl font-bold text-slate-800">{recommendedCount}</p>
              <p className="text-sm text-slate-500">推荐商品</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border shadow-sm">
        <div className="p-4 border-b"><h2 className="font-semibold text-slate-800">📝 最近录入商品</h2></div>
        <div className="divide-y">
          {recentProducts.map((product) => (
            <div key={product.id} className="p-4 flex items-center justify-between hover:bg-slate-50">
              <div>
                <p className="font-medium text-slate-800">{product.skuCode}</p>
                <p className="text-sm text-slate-500">{product.merchant.market.name} - {product.merchant.boothCode}档口 | {product.category.name} | {product.deviceModel.name}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-slate-500">{new Date(product.createdAt).toLocaleDateString("zh-CN")}</p>
              </div>
            </div>
          ))}
          {recentProducts.length === 0 && <div className="p-8 text-center text-slate-500">暂无商品数据</div>}
        </div>
      </div>
    </div>
  );
}