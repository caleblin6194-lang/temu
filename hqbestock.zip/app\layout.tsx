import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "华强北选品管理系统",
  description: "华强北跨境选品与档口配货管理系统",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="zh-CN">
      <body>
        <div className="min-h-screen bg-slate-50">
          <header className="bg-slate-900 text-white shadow-lg">
            <div className="container mx-auto px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-8">
                <Link href="/" className="text-xl font-bold text-yellow-400">
                  华强北选品系统
                </Link>
                <nav className="flex gap-6 text-sm">
                  <Link href="/dashboard" className="hover:text-yellow-400 transition">仪表盘</Link>
                  <Link href="/merchants" className="hover:text-yellow-400 transition">商家管理</Link>
                  <Link href="/products" className="hover:text-yellow-400 transition">商品管理</Link>
                  <Link href="/pricing" className="hover:text-yellow-400 transition">Temu核价</Link>
                  <Link href="/quotes" className="hover:text-yellow-400 transition">商家报价</Link>
                  <Link href="/profit" className="hover:text-yellow-400 transition">利润分析</Link>
                  <Link href="/print" className="hover:text-yellow-400 transition">标签打印</Link>
                  <Link href="/pick" className="hover:text-yellow-400 transition">档口配货</Link>
                </nav>
              </div>
              <div className="flex items-center gap-4">
                <select className="bg-slate-800 text-sm px-3 py-1 rounded border border-slate-700">
                  <option value="admin">👑 管理员</option>
                  <option value="staff">👷 档口员工</option>
                </select>
              </div>
            </div>
          </header>
          <main className="container mx-auto px-4 py-6">
            {children}
          </main>
        </div>
      </body>
    </html>
  );
}