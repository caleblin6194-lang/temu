import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";

// 获取字典数据
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get("type");

    let data;
    switch (type) {
      case "markets":
        data = await prisma.market.findMany({ orderBy: { id: "asc" } });
        break;
      case "categories":
        data = await prisma.category.findMany({ orderBy: { id: "asc" } });
        break;
      case "series":
        data = await prisma.series.findMany({ orderBy: { id: "asc" } });
        break;
      case "deviceModels":
        data = await prisma.deviceModel.findMany({ orderBy: { id: "asc" } });
        break;
      case "colors":
        data = await prisma.color.findMany({ orderBy: { id: "asc" } });
        break;
      case "merchants":
        data = await prisma.merchant.findMany({ include: { market: true }, orderBy: { id: "asc" } });
        break;
      default:
        data = {
          markets: await prisma.market.findMany({ orderBy: { id: "asc" } }),
          categories: await prisma.category.findMany({ orderBy: { id: "asc" } }),
          series: await prisma.series.findMany({ orderBy: { id: "asc" } }),
          deviceModels: await prisma.deviceModel.findMany({ orderBy: { id: "asc" } }),
          colors: await prisma.color.findMany({ orderBy: { id: "asc" } }),
        };
    }
    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json({ error: "获取失败" }, { status: 500 });
  }
}