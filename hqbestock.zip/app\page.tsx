import Link from "next/link";
import { Store, Package, TrendingUp, DollarSign, Printer, ShoppingCart, Users, BarChart3 } from "lucide-react";

export default function Home() {
  return (
    <div className="space-y-8">
      <div className="bg-gradient-to-r from-slate-800 to-slate-700 rounded-xl p-8 text-white">
        <h1 className="text-3xl font-bold mb-2">欢迎使用华强北选品管理系统</h1>
        <p className="text-slate-300">统一管理商家资料、商品选品、Temu核价、利润测算与档口配货</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Link href="/merchants" className="bg-white rounded-xl p-6 shadow-sm border hover:shadow-md transition group">
          <Users className="w-10 h-10 text-blue-600 mb-3" />
          <h3 className="font-semibold text-slate-800 group-hover:text-blue-600">商家管理</h3>
          <p className="text-sm text-slate-500">录入华强北档口信息</p>
        </Link>

        <Link href="/products" className="bg-white rounded-xl p-6 shadow-sm border hover:shadow-md transition group">
          <Package className="w-10 h-10 text-green-600 mb-3" />
          <h3 className="font-semibold text-slate-800 group-hover:text-green-600">商品管理</h3>
          <p className="text-sm text-slate-500">录入商品生成SKU</p>
        </Link>

        <Link href="/pricing" className="bg-white rounded-xl p-6 shadow-sm border hover:shadow-md transition group">
          <TrendingUp className="w-10 h-10 text-orange-600 mb-3" />
          <h3 className="font-semibold text-slate-800 group-hover:text-orange-600">Temu核价</h3>
          <p className="text-sm text-slate-500">记录Temu平台核价</p>
        </Link>

        <Link href="/profit" className="bg-white rounded-xl p-6 shadow-sm border hover:shadow-md transition group">
          <DollarSign className="w-10 h-10 text-purple-600 mb-3" />
          <h3 className="font-semibold text-slate-800 group-hover:text-purple-600">利润分析</h3>
          <p className="text-sm text-slate-500">计算利润与推荐</p>
        </Link>

        <Link href="/print" className="bg-white rounded-xl p-6 shadow-sm border hover:shadow-md transition group">
          <Printer className="w-10 h-10 text-red-600 mb-3" />
          <h3 className="font-semibold text-slate-800 group-hover:text-red-600">标签打印</h3>
          <p className="text-sm text-slate-500">打印SKU条码标签</p>
        </Link>

        <Link href="/pick" className="bg-white rounded-xl p-6 shadow-sm border hover:shadow-md transition group">
          <ShoppingCart className="w-10 h-10 text-teal-600 mb-3" />
          <h3 className="font-semibold text-slate-800 group-hover:text-teal-600">档口配货</h3>
          <p className="text-sm text-slate-500">档口员工配货视图</p>
        </Link>

        <Link href="/quotes" className="bg-white rounded-xl p-6 shadow-sm border hover:shadow-md transition group col-span-2">
          <BarChart3 className="w-10 h-10 text-yellow-600 mb-3" />
          <h3 className="font-semibold text-slate-800 group-hover:text-yellow-600">商家报价</h3>
          <p className="text-sm text-slate-500">记录各档口供货价格</p>
        </Link>
      </div>

      <div className="bg-white rounded-xl p-6 border">
        <h2 className="text-lg font-semibold mb-4">💡 快速开始</h2>
        <ol className="list-decimal list-inside space-y-2 text-slate-600">
          <li>先在 <strong>商家管理</strong> 录入档口信息</li>
          <li>在 <strong>商品管理</strong> 录入商品，自动生成SKU编码</li>
          <li>在 <strong>Temu核价</strong> 记录平台核价结果</li>
          <li>在 <strong>商家报价</strong> 记录档口供货价</li>
          <li>系统自动计算 <strong>利润</strong>，判断是否推荐</li>
          <li>最后在 <strong>标签打印</strong> 打印条码配货</li>
        </ol>
      </div>
    </div>
  );
}