import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 开始种子数据...');

  // 1. 市场
  const markets = await Promise.all([
    prisma.market.upsert({
      where: { code: 'SG' },
      update: {},
      create: { code: 'SG', name: '赛格广场' },
    }),
    prisma.market.upsert({
      where: { code: 'HQB' },
      update: {},
      create: { code: 'HQB', name: '华强北电子城' },
    }),
    prisma.market.upsert({
      where: { code: 'SYB' },
      update: {},
      create: { code: 'SYB', name: '赛博' },
    }),
    prisma.market.upsert({
      where: { code: 'YHD' },
      update: {},
      create: { code: 'YHD', name: '远望数码城' },
    }),
  ]);
  console.log('✅ 市场数据创建完成');

  // 2. 品类
  const categories = await Promise.all([
    prisma.category.upsert({ where: { code: 'SK' }, update: {}, create: { code: 'SK', name: '手机壳' } }),
    prisma.category.upsert({ where: { code: 'CD' }, update: {}, create: { code: 'CD', name: '充电器' } }),
    prisma.category.upsert({ where: { code: 'SX' }, update: {}, create: { code: 'SX', name: '数据线' } }),
    prisma.category.upsert({ where: { code: 'GM' }, update: {}, create: { code: 'GM', name: '钢化膜' } }),
    prisma.category.upsert({ where: { code: 'EJ' }, update: {}, create: { code: 'EJ', name: '耳机' } }),
  ]);
  console.log('✅ 品类数据创建完成');

  // 3. 系列
  const seriesList = await Promise.all([
    prisma.series.upsert({ where: { code: 'CX' }, update: {}, create: { code: 'CX', name: '磁吸' } }),
    prisma.series.upsert({ where: { code: 'FS' }, update: {}, create: { code: 'FS', name: '防摔' } }),
    prisma.series.upsert({ where: { code: 'TM' }, update: {}, create: { code: 'TM', name: '透明' } }),
    prisma.series.upsert({ where: { code: 'MS' }, update: {}, create: { code: 'MS', name: '磨砂' } }),
    prisma.series.upsert({ where: { code: 'PW' }, update: {}, create: { code: 'PW', name: '皮纹' } }),
    prisma.series.upsert({ where: { code: 'CB' }, update: {}, create: { code: 'CB', name: '超薄' } }),
  ]);
  console.log('✅ 系列数据创建完成');

  // 4. 型号
  const deviceModels = await Promise.all([
    prisma.deviceModel.upsert({ where: { code: 'IP15PM' }, update: {}, create: { code: 'IP15PM', name: 'iPhone 15 Pro Max', brand: 'Apple' } }),
    prisma.deviceModel.upsert({ where: { code: 'IP15P' }, update: {}, create: { code: 'IP15P', name: 'iPhone 15 Pro', brand: 'Apple' } }),
    prisma.deviceModel.upsert({ where: { code: 'IP15' }, update: {}, create: { code: 'IP15', name: 'iPhone 15', brand: 'Apple' } }),
    prisma.deviceModel.upsert({ where: { code: 'IP14PM' }, update: {}, create: { code: 'IP14PM', name: 'iPhone 14 Pro Max', brand: 'Apple' } }),
    prisma.deviceModel.upsert({ where: { code: 'IP14P' }, update: {}, create: { code: 'IP14P', name: 'iPhone 14 Pro', brand: 'Apple' } }),
    prisma.deviceModel.upsert({ where: { code: 'IP14' }, update: {}, create: { code: 'IP14', name: 'iPhone 14', brand: 'Apple' } }),
    prisma.deviceModel.upsert({ where: { code: 'SS24U' }, update: {}, create: { code: 'SS24U', name: 'Samsung S24 Ultra', brand: 'Samsung' } }),
    prisma.deviceModel.upsert({ where: { code: 'SS24P' }, update: {}, create: { code: 'SS24P', name: 'Samsung S24+', brand: 'Samsung' } }),
    prisma.deviceModel.upsert({ where: { code: 'SS24' }, update: {}, create: { code: 'SS24', name: 'Samsung S24', brand: 'Samsung' } }),
    prisma.deviceModel.upsert({ where: { code: 'XM14' }, update: {}, create: { code: 'XM14', name: 'Xiaomi 14', brand: 'Xiaomi' } }),
  ]);
  console.log('✅ 型号数据创建完成');

  // 5. 颜色
  const colors = await Promise.all([
    prisma.color.upsert({ where: { code: 'H' }, update: {}, create: { code: 'H', name: '黑' } }),
    prisma.color.upsert({ where: { code: 'B' }, update: {}, create: { code: 'B', name: '白' } }),
    prisma.color.upsert({ where: { code: 'L' }, update: {}, create: { code: 'L', name: '蓝' } }),
    prisma.color.upsert({ where: { code: 'F' }, update: {}, create: { code: 'F', name: '粉' } }),
    prisma.color.upsert({ where: { code: 'G' }, update: {}, create: { code: 'G', name: '绿' } }),
    prisma.color.upsert({ where: { code: 'T' }, update: {}, create: { code: 'T', name: '透明' } }),
    prisma.color.upsert({ where: { code: 'R' }, update: {}, create: { code: 'R', name: '红' } }),
    prisma.color.upsert({ where: { code: 'GY' }, update: {}, create: { code: 'GY', name: '灰' } }),
  ]);
  console.log('✅ 颜色数据创建完成');

  // 6. 商家
  const merchants = await Promise.all([
    prisma.merchant.upsert({
      where: { marketId_boothCode: { marketId: 1, boothCode: 'A12' } },
      update: {},
      create: { marketId: 1, boothCode: 'A12', boothLocation: '赛格广场3楼3A012', merchantName: '华强精品壳王', contactName: '张老板', wechat: 'zhang888', qq: '123456', phone: '13800138000', mainCategory: '手机壳' },
    }),
    prisma.merchant.upsert({
      where: { marketId_boothCode: { marketId: 1, boothCode: 'B08' } },
      update: {},
      create: { marketId: 1, boothCode: 'B08', boothLocation: '赛格广场4楼4B008', merchantName: '数码配件批发', contactName: '李姐', wechat: 'lijie666', qq: '234567', phone: '13800138001', mainCategory: '充电器/数据线' },
    }),
    prisma.merchant.upsert({
      where: { marketId_boothCode: { marketId: 2, boothCode: 'C01' } },
      update: {},
      create: { marketId: 2, boothCode: 'C01', boothLocation: '华强北电子城1楼C001', merchantName: '诚信电子', contactName: '王总', wechat: 'wang888', qq: '345678', phone: '13800138002', mainCategory: '钢化膜' },
    }),
    prisma.merchant.upsert({
      where: { marketId_boothCode: { marketId: 2, boothCode: 'D15' } },
      update: {},
      create: { marketId: 2, boothCode: 'D15', boothLocation: '华强北电子城2楼D015', merchantName: '耳机工厂店', contactName: '赵经理', wechat: 'zhao999', qq: '456789', phone: '13800138003', mainCategory: '耳机' },
    }),
    prisma.merchant.upsert({
      where: { marketId_boothCode: { marketId: 3, boothCode: 'E22' } },
      update: {},
      create: { marketId: 3, boothCode: 'E22', boothLocation: '赛博2楼E022', merchantName: '赛博精品配件', contactName: '钱老板', wechat: 'qian666', qq: '567890', phone: '13800138004', mainCategory: '手机壳/膜' },
    }),
    prisma.merchant.upsert({
      where: { marketId_boothCode: { marketId: 4, boothCode: 'F08' } },
      update: {},
      create: { marketId: 4, boothCode: 'F08', boothLocation: '远望数码城1楼F008', merchantName: '远望数码', contactName: '孙总', wechat: 'sun888', qq: '678901', phone: '13800138005', mainCategory: '全品类' },
    }),
  ]);
  console.log('✅ 商家数据创建完成');

  // 7. 商品 (20个示例)
  const products = await Promise.all([
    prisma.product.upsert({
      where: { skuCode: 'SG-A12-SK-CX-IP15PM-H-001' },
      update: {},
      create: { merchantId: 1, categoryId: 1, seriesId: 1, deviceModelId: 1, colorId: 1, skuCode: 'SG-A12-SK-CX-IP15PM-H-001', serialNo: 1, imageUrl: '/uploads/placeholder.png', note: '磁吸壳-iPhone15ProMax-黑色' },
    }),
    prisma.product.upsert({
      where: { skuCode: 'SG-A12-SK-CX-IP15PM-B-002' },
      update: {},
      create: { merchantId: 1, categoryId: 1, seriesId: 1, deviceModelId: 1, colorId: 2, skuCode: 'SG-A12-SK-CX-IP15PM-B-002', serialNo: 2, imageUrl: '/uploads/placeholder.png', note: '磁吸壳-iPhone15ProMax-白色' },
    }),
    prisma.product.upsert({
      where: { skuCode: 'SG-B08-CD-FS-IP15P-L-001' },
      update: {},
      create: { merchantId: 2, categoryId: 2, seriesId: 2, deviceModelId: 2, colorId: 3, skuCode: 'SG-B08-CD-FS-IP15P-L-001', serialNo: 1, imageUrl: '/uploads/placeholder.png', note: '防摔充电器-iPhone15Pro-蓝色' },
    }),
    prisma.product.upsert({
      where: { skuCode: 'HQB-C01-GM-TM-IP14PM-T-001' },
      update: {},
      create: { merchantId: 3, categoryId: 4, seriesId: 3, deviceModelId: 4, colorId: 6, skuCode: 'HQB-C01-GM-TM-IP14PM-T-001', serialNo: 1, imageUrl: '/uploads/placeholder.png', note: '透明钢化膜-iPhone14ProMax-透明' },
    }),
    prisma.product.upsert({
      where: { skuCode: 'HQB-D15-EJ-CX-IP15-F-001' },
      update: {},
      create: { merchantId: 4, categoryId: 5, seriesId: 1, deviceModelId: 3, colorId: 4, skuCode: 'HQB-D15-EJ-CX-IP15-F-001', serialNo: 1, imageUrl: '/uploads/placeholder.png', note: '磁吸耳机-iPhone15-粉色' },
    }),
    prisma.product.upsert({
      where: { skuCode: 'SYB-E22-SK-PW-SS24U-G-001' },
      update: {},
      create: { merchantId: 5, categoryId: 1, seriesId: 5, deviceModelId: 7, colorId: 5, skuCode: 'SYB-E22-SK-PW-SS24U-G-001', serialNo: 1, imageUrl: '/uploads/placeholder.png', note: '皮纹壳-SamsungS24Ultra-绿色' },
    }),
  ]);
  // 创建更多商品
  for (let i = 0; i < 14; i++) {
    const idx = i + 1;
    const sku = `SG-A12-SK-CX-IP${15-idx%3}PM-${['H','B','L','F','G','T'][idx%6]}-${String(idx+3).padStart(3, '0')}`;
    await prisma.product.upsert({
      where: { skuCode: sku },
      update: {},
      create: {
        merchantId: (i % 6) + 1,
        categoryId: (i % 5) + 1,
        seriesId: (i % 6) + 1,
        deviceModelId: (i % 10) + 1,
        colorId: (i % 8) + 1,
        skuCode: sku,
        serialNo: idx + 3,
        imageUrl: '/uploads/placeholder.png',
        note: `示例商品${idx+6}`,
      },
    });
  }
  console.log('✅ 商品数据创建完成');

  // 8. Temu核价记录
  const pricingData = [
    { productId: 1, temuPrice: 45.9, status: 'approved' },
    { productId: 2, temuPrice: 42.9, status: 'approved' },
    { productId: 3, temuPrice: 35.0, status: 'pending' },
    { productId: 4, temuPrice: 18.8, status: 'approved' },
    { productId: 5, temuPrice: 68.0, status: 'rejected' },
    { productId: 6, temuPrice: 55.5, status: 'approved' },
  ];
  for (const p of pricingData) {
    await prisma.temuPricing.upsert({
      where: { productId: p.productId },
      update: {},
      create: {
        productId: p.productId,
        temuPrice: p.temuPrice,
        pricingDate: new Date(),
        status: p.status,
      },
    });
  }
  console.log('✅ Temu核价数据创建完成');

  // 9. 商家报价
  const quoteData = [
    { productId: 1, merchantId: 1, supplierPrice: 18.0, logisticsCost: 2.5, platformFee: 3.0, extraCost: 0 },
    { productId: 2, merchantId: 1, supplierPrice: 16.5, logisticsCost: 2.5, platformFee: 3.0, extraCost: 0 },
    { productId: 3, merchantId: 2, supplierPrice: 12.0, logisticsCost: 2.0, platformFee: 2.5, extraCost: 0 },
    { productId: 4, merchantId: 3, supplierPrice: 5.5, logisticsCost: 1.5, platformFee: 1.5, extraCost: 0 },
    { productId: 5, merchantId: 4, supplierPrice: 28.0, logisticsCost: 3.0, platformFee: 4.0, extraCost: 1 },
    { productId: 6, merchantId: 5, supplierPrice: 22.0, logisticsCost: 2.8, platformFee: 3.5, extraCost: 0.5 },
  ];
  for (const q of quoteData) {
    // 先检查是否已存在
    const existing = await prisma.supplierQuote.findFirst({
      where: { productId: q.productId, merchantId: q.merchantId }
    });
    if (!existing) {
      await prisma.supplierQuote.create({ data: q });
    }
  }
  console.log('✅ 商家报价数据创建完成');

  // 10. 配货任务
  const pickData = [
    { productId: 1, quantity: 50, status: 'pending' },
    { productId: 2, quantity: 30, status: 'pending' },
    { productId: 3, quantity: 100, status: 'completed' },
    { productId: 4, quantity: 80, status: 'pending' },
    { productId: 5, quantity: 20, status: 'pending' },
  ];
  for (const p of pickData) {
    await prisma.pickTask.upsert({
      where: { id: p.productId },
      update: {},
      create: p,
    });
  }
  console.log('✅ 配货任务数据创建完成');

  console.log('🎉 种子数据创建完毕！');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
