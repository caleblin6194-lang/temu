"use client";
import { useState, useEffect } from "react";
import { Plus, Search, Trash2, X } from "lucide-react";

interface Product {
  id: number;
  skuCode: string;
  category: { name: string };
  deviceModel: { name: string };
  color: { name: string };
}

interface Merchant {
  id: number;
  market: { name: string };
  boothCode: string;
  merchantName: string;
}

interface Quote {
  id: number;
  productId: number;
  merchantId: number;
  supplierPrice: number;
  logisticsCost: number;
  platformFee: number;
  extraCost: number;
  product: Product;
  merchant: Merchant;
}

export default function QuotesPage() {
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [merchants, setMerchants] = useState<Merchant[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  
  const [search, setSearch] = useState("");
  const [merchantFilter, setMerchantFilter] = useState("");
  
  const [form, setForm] = useState({
    productId: "",
    merchantId: "",
    supplierPrice: "",
    logisticsCost: "2",
    platformFee: "2",
    extraCost: "0",
  });

  // 加载数据
  useEffect(() => {
    Promise.all([
      fetch("/api/quotes").then(r => r.json()),
      fetch("/api/products").then(r => r.json()),
      fetch("/api/merchants").then(r => r.json()),
    ]).then(([quotesData, productsData, merchantsData]) => {
      setQuotes(quotesData);
      setProducts(productsData);
      setMerchants(merchantsData);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  // 过滤
  const filteredQuotes = quotes.filter(q => {
    if (search && !q.product.skuCode.toLowerCase().includes(search.toLowerCase())) return false;
    if (merchantFilter && q.merchantId !== parseInt(merchantFilter)) return false;
    return true;
  });

  // 新增报价
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.productId || !form.merchantId || !form.supplierPrice) {
      alert("请填写完整信息");
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/quotes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productId: parseInt(form.productId),
          merchantId: parseInt(form.merchantId),
          supplierPrice: parseFloat(form.supplierPrice),
          logisticsCost: parseFloat(form.logisticsCost) || 0,
          platformFee: parseFloat(form.platformFee) || 0,
          extraCost: parseFloat(form.extraCost) || 0,
        }),
      });
      if (res.ok) {
        const updated = await fetch("/api/quotes").then(r => r.json());
        setQuotes(updated);
        setShowModal(false);
        setForm({ productId: "", merchantId: "", supplierPrice: "", logisticsCost: "2", platformFee: "2", extraCost: "0" });
        alert("报价记录创建成功！");
      } else {
        alert("创建失败");
      }
    } catch { alert("创建失败"); }
    setSubmitting(false);
  };

  // 删除报价
  const handleDelete = async (id: number) => {
    if (!confirm("确定删除这条报价记录？")) return;
    try {
      const res = await fetch(`/api/quotes?id=${id}`, { method: "DELETE" });
      if (res.ok) {
        setQuotes(quotes.filter(q => q.id !== id));
        alert("删除成功");
      } else {
        alert("删除失败");
      }
    } catch { alert("删除失败"); }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-800">💵 商家报价记录</h1>
        <button onClick={() => setShowModal(true)} className="flex items-center gap-2 bg-slate-900 text-white px-4 py-2 rounded-lg hover:bg-slate-800">
          <Plus className="w-4 h-4" /> 新增报价
        </button>
      </div>

      {/* 搜索筛选 */}
      <div className="bg-white rounded-xl border p-4">
        <div className="flex gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="搜索SKU..." className="w-full pl-10 pr-4 py-2 border rounded-lg" />
          </div>
          <select value={merchantFilter} onChange={e => setMerchantFilter(e.target.value)} className="border rounded-lg px-4 py-2">
            <option value="">全部商家</option>
            {merchants.map(m => <option key={m.id} value={m.id}>{m.market.name} {m.boothCode} - {m.merchantName}</option>)}
          </select>
        </div>
      </div>

      {/* 列表 */}
      <div className="bg-white rounded-xl border overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50 border-b">
            <tr>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">SKU</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">商品</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">商家</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">供货价</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">物流</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">平台费</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">其他</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">操作</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {filteredQuotes.map((q) => (
              <tr key={q.id} className="hover:bg-slate-50">
                <td className="p-3"><code className="text-xs bg-slate-100 px-2 py-1 rounded">{q.product.skuCode}</code></td>
                <td className="p-3 text-sm">{q.product.category.name} | {q.product.deviceModel.name} | {q.product.color.name}</td>
                <td className="p-3 text-sm">{q.merchant.merchantName}</td>
                <td className="p-3 font-medium">¥{q.supplierPrice}</td>
                <td className="p-3 text-slate-500">¥{q.logisticsCost}</td>
                <td className="p-3 text-slate-500">¥{q.platformFee}</td>
                <td className="p-3 text-slate-500">¥{q.extraCost}</td>
                <td className="p-3">
                  <button onClick={() => handleDelete(q.id)} className="p-2 hover:bg-red-50 rounded text-red-600"><Trash2 className="w-4 h-4" /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredQuotes.length === 0 && <div className="p-8 text-center text-slate-500">暂无报价数据</div>}
      </div>

      {/* 新增弹窗 */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold">新增报价</h2>
              <button onClick={() => setShowModal(false)} className="p-2 hover:bg-slate-100 rounded"><X className="w-5 h-5" /></button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">选择商品 <span className="text-red-500">*</span></label>
                <select required value={form.productId} onChange={e => setForm({...form, productId: e.target.value})} className="w-full border rounded-lg px-3 py-2">
                  <option value="">选择商品</option>
                  {products.map(p => <option key={p.id} value={p.id}>{p.skuCode}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">选择商家 <span className="text-red-500">*</span></label>
                <select required value={form.merchantId} onChange={e => setForm({...form, merchantId: e.target.value})} className="w-full border rounded-lg px-3 py-2">
                  <option value="">选择商家</option>
                  {merchants.map(m => <option key={m.id} value={m.id}>{m.market.name} {m.boothCode} - {m.merchantName}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">供货价 <span className="text-red-500">*</span></label>
                <input required type="number" step="0.01" value={form.supplierPrice} onChange={e => setForm({...form, supplierPrice: e.target.value})} placeholder="供货价" className="w-full border rounded-lg px-3 py-2" />
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">物流</label>
                  <input type="number" step="0.01" value={form.logisticsCost} onChange={e => setForm({...form, logisticsCost: e.target.value})} className="w-full border rounded-lg px-3 py-2" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">平台费</label>
                  <input type="number" step="0.01" value={form.platformFee} onChange={e => setForm({...form, platformFee: e.target.value})} className="w-full border rounded-lg px-3 py-2" />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">其他</label>
                  <input type="number" step="0.01" value={form.extraCost} onChange={e => setForm({...form, extraCost: e.target.value})} className="w-full border rounded-lg px-3 py-2" />
                </div>
              </div>
              <div className="flex gap-4 pt-2">
                <button type="submit" disabled={submitting} className="flex-1 bg-slate-900 text-white py-2 rounded-lg hover:bg-slate-800 disabled:opacity-50">
                  {submitting ? "保存中..." : "保存"}
                </button>
                <button type="button" onClick={() => setShowModal(false)} className="px-6 py-2 border rounded-lg hover:bg-slate-50">取消</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}