"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { ArrowLeft, Printer, Check } from "lucide-react";

interface Product {
  id: number;
  skuCode: string;
  category: { name: string };
  series: { name: string };
  deviceModel: { name: string; code: string };
  color: { name: string };
  merchant: { market: { name: string }; boothCode: string };
}

export default function PrintPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [selected, setSelected] = useState<number[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/products")
      .then(res => res.json())
      .then(data => {
        setProducts(data.slice(0, 50));
        setLoading(false);
      })
      .catch(() => {
        // Mock data fallback
        setProducts([
          { id: 1, skuCode: "SG-A12-SK-CX-IP15PM-H-001", category: { name: "手机壳" }, series: { name: "磁吸" }, deviceModel: { name: "iPhone 15 Pro Max", code: "IP15PM" }, color: { name: "黑" }, merchant: { market: { name: "赛格广场" }, boothCode: "A12" } },
          { id: 2, skuCode: "SG-A12-SK-CX-IP15PM-B-002", category: { name: "手机壳" }, series: { name: "磁吸" }, deviceModel: { name: "iPhone 15 Pro Max", code: "IP15PM" }, color: { name: "白" }, merchant: { market: { name: "赛格广场" }, boothCode: "A12" } },
          { id: 3, skuCode: "HQB-C01-GM-TM-IP14PM-T-001", category: { name: "钢化膜" }, series: { name: "透明" }, deviceModel: { name: "iPhone 14 Pro Max", code: "IP14PM" }, color: { name: "透明" }, merchant: { market: { name: "华强北电子城" }, boothCode: "C01" } },
          { id: 4, skuCode: "SYB-E22-SK-PW-SS24U-G-001", category: { name: "手机壳" }, series: { name: "皮纹" }, deviceModel: { name: "Samsung S24 Ultra", code: "SS24U" }, color: { name: "绿" }, merchant: { market: { name: "赛博" }, boothCode: "E22" } },
        ]);
        setLoading(false);
      });
  }, []);

  // 生成条码
  const generateBarcode = (sku: string, el: HTMLDivElement | null) => {
    if (el && typeof window !== "undefined") {
      import("jsbarcode").then(({ default: JsBarcode }) => {
        try {
          JsBarcode(el, sku, { format: "CODE128", width: 2, height: 50, displayValue: false });
        } catch (e) { console.error(e); }
      });
    }
  };

  const toggleSelect = (id: number) => {
    setSelected(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const selectAll = () => {
    if (selected.length === products.length) setSelected([]);
    else setSelected(products.map(p => p.id));
  };

  const filtered = products.filter(p => p.skuCode.toLowerCase().includes(search.toLowerCase()));

  const handlePrint = () => {
    const printContent = document.getElementById('print-area');
    if (!printContent) return;
    
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    
    printWindow.document.write(`
      <html>
        <head>
          <title>打印标签</title>
          <style>
            body { margin: 0; padding: 20px; font-family: sans-serif; }
            .label { 
              width: 45%; 
              display: inline-block; 
              border: 2px dashed #ccc; 
              padding: 10px; 
              margin: 10px;
              box-sizing: border-box;
              page-break-inside: avoid;
            }
            .label-row { display: flex; flex-wrap: wrap; }
            .market { font-weight: bold; }
            .short-label { font-size: 16px; font-weight: bold; text-align: center; margin: 10px 0; }
            .sku { text-align: center; font-size: 12px; color: #666; }
            .barcode { text-align: center; margin-top: 10px; }
            @media print {
              .label { border: 1px dashed #999; }
              body { -webkit-print-color-adjust: exact; }
            }
          </style>
        </head>
        <body>
          <div class="label-row">
            ${products.filter(p => selected.includes(p.id)).map(p => `
              <div class="label">
                <div><span class="market">${p.merchant.market.name}</span> ${p.merchant.boothCode}档口</div>
                <div class="short-label">${p.series.name}壳｜${p.deviceModel.code.replace('IP','').replace('PM','PM').replace('P','P')}｜${p.color.name}</div>
                <div class="sku">${p.skuCode}</div>
                <div class="barcode"><svg class="barcode-svg" data-sku="${p.skuCode}"></svg></div>
              </div>
            `).join('')}
          </div>
          <script>
            ${require('jsbarcode').default.toString()}
            document.querySelectorAll('.barcode-svg').forEach(el => {
              const sku = el.dataset.sku;
              try {
                JsBarcode(el, sku, { format: "CODE128", width: 2, height: 40, displayValue: false });
              } catch(e) {}
            });
            window.onload = function() { 
              setTimeout(function() { 
                window.print(); 
                window.close(); 
              }, 500); 
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/products" className="p-2 hover:bg-slate-100 rounded"><ArrowLeft className="w-5 h-5" /></Link>
        <h1 className="text-2xl font-bold text-slate-800">🏷️ 标签打印</h1>
      </div>

      {/* 选择商品 */}
      <div className="bg-white rounded-xl border p-4">
        <div className="flex gap-4 mb-4">
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="搜索SKU..." className="flex-1 border rounded-lg px-4 py-2" />
          <button onClick={selectAll} className="bg-slate-100 px-4 py-2 rounded-lg hover:bg-slate-200">
            {selected.length === products.length ? "取消全选" : "全选"} ({products.length})
          </button>
        </div>

        {loading ? (
          <div className="text-center py-8 text-slate-500">加载中...</div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {filtered.map(p => (
              <div key={p.id} onClick={() => toggleSelect(p.id)} className={`p-3 border rounded-lg cursor-pointer transition ${selected.includes(p.id) ? 'border-blue-500 bg-blue-50' : 'hover:border-slate-300'}`}>
                <div className="flex items-center gap-2">
                  <div className={`w-5 h-5 rounded border flex items-center justify-center ${selected.includes(p.id) ? 'bg-blue-500 border-blue-500' : 'border-slate-300'}`}>
                    {selected.includes(p.id) && <Check className="w-3 h-3 text-white" />}
                  </div>
                  <code className="text-xs">{p.skuCode}</code>
                </div>
                <p className="text-xs text-slate-500 mt-1">{p.category.name} | {p.deviceModel.name}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 打印预览 */}
      {selected.length > 0 && (
        <div className="bg-white rounded-xl border p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">打印预览 ({selected.length}个标签)</h2>
            <button onClick={handlePrint} className="flex items-center gap-2 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700">
              <Printer className="w-4 h-4" /> 打印标签
            </button>
          </div>

          <div id="print-area" className="grid grid-cols-2 gap-4">
            {products.filter(p => selected.includes(p.id)).map(p => (
              <div key={p.id} className="border-2 border-dashed border-slate-300 p-4 rounded-lg">
                <div className="flex justify-between text-sm mb-2">
                  <span className="font-bold">{p.merchant.market.name}</span>
                  <span>{p.merchant.boothCode}档口</span>
                </div>
                <div className="text-center text-lg font-bold mb-2 text-orange-600">
                  {p.series.name}壳｜{p.deviceModel.code.replace('IP','').replace('PM','PM').replace('P','P')}｜{p.color.name}
                </div>
                <div className="text-center text-xs text-slate-500 mb-2">{p.skuCode}</div>
                <BarcodeGenerator sku={p.skuCode} />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// 条码生成组件
function BarcodeGenerator({ sku }: { sku: string }) {
  const ref = useRef<SVGSVGElement>(null);
  
  useEffect(() => {
    if (ref.current) {
      import("jsbarcode").then(({ default: JsBarcode }) => {
        try {
          JsBarcode(ref.current, sku, { format: "CODE128", width: 2, height: 50, displayValue: false });
        } catch (e) {}
      });
    }
  }, [sku]);
  
  return <svg ref={ref} className="w-full"></svg>;
}