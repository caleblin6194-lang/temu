import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";

// 获取商家列表
export async function GET() {
  try {
    const merchants = await prisma.merchant.findMany({
      include: { market: true },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json(merchants);
  } catch (error) {
    return NextResponse.json({ error: "获取失败" }, { status: 500 });
  }
}

// 创建商家
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { marketId, boothCode, boothLocation, merchantName, contactName, wechat, qq, phone, mainCategory, remark } = body;

    // 检查档口是否已存在
    const existing = await prisma.merchant.findUnique({
      where: { marketId_boothCode: { marketId, boothCode } },
    });
    if (existing) {
      return NextResponse.json({ error: "该档口已存在" }, { status: 400 });
    }

    const merchant = await prisma.merchant.create({
      data: { marketId, boothCode, boothLocation, merchantName, contactName, wechat, qq, phone, mainCategory, remark },
    });

    return NextResponse.json(merchant);
  } catch (error) {
    return NextResponse.json({ error: "创建失败" }, { status: 500 });
  }
}