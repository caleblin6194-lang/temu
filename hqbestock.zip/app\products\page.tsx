import prisma from "@/lib/prisma";
import { Plus, Search, Edit, Eye } from "lucide-react";
import Link from "next/link";

export default async function ProductsPage({ searchParams }: { searchParams: { q?: string; category?: string; market?: string } }) {
  const { q, category, market } = searchParams;
  const where: any = {};
  if (q) where.OR = [{ skuCode: { contains: q } }, { note: { contains: q } }];
  if (category) where.categoryId = parseInt(category);
  if (market) where.merchant = { marketId: parseInt(market) };

  const [products, categories, markets] = await Promise.all([
    prisma.product.findMany({
      where, include: { merchant: { include: { market: true } }, category: true, series: true, deviceModel: true, color: true },
      orderBy: { createdAt: "desc" }, take: 50,
    }),
    prisma.category.findMany(),
    prisma.market.findMany(),
  ]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-800">📦 商品管理</h1>
        <Link href="/products/new" className="flex items-center gap-2 bg-slate-900 text-white px-4 py-2 rounded-lg hover:bg-slate-800">
          <Plus className="w-4 h-4" /> 新增商品
        </Link>
      </div>

      <div className="bg-white rounded-xl border p-4">
        <form className="flex flex-wrap gap-4">
          <div className="flex-1 min-w-[200px] relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input name="q" defaultValue={q} placeholder="搜索SKU编码..." className="w-full pl-10 pr-4 py-2 border rounded-lg" />
          </div>
          <select name="category" defaultValue={category} className="border rounded-lg px-4 py-2">
            <option value="">全部品类</option>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <select name="market" defaultValue={market} className="border rounded-lg px-4 py-2">
            <option value="">全部市场</option>
            {markets.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
          </select>
          <button type="submit" className="bg-slate-100 px-4 py-2 rounded-lg hover:bg-slate-200">搜索</button>
        </form>
      </div>

      <div className="bg-white rounded-xl border overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50 border-b">
            <tr>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">SKU编码</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">商家/档口</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">品类</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">型号/颜色</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">图片</th>
              <th className="text-left p-3 font-medium text-slate-600 text-sm">操作</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {products.map((p) => (
              <tr key={p.id} className="hover:bg-slate-50">
                <td className="p-3"><code className="text-xs bg-slate-100 px-2 py-1 rounded">{p.skuCode}</code></td>
                <td className="p-3 text-sm">
                  <div>{p.merchant.market.name}</div>
                  <div className="text-slate-500">{p.merchant.boothCode}档口</div>
                </td>
                <td className="p-3 text-sm"><div>{p.category.name}</div><div className="text-slate-500">{p.series.name}</div></td>
                <td className="p-3 text-sm"><div>{p.deviceModel.name}</div><div className="text-slate-500">{p.color.name}</div></td>
                <td className="p-3">
                  {p.imageUrl ? <div className="w-10 h-10 bg-slate-100 rounded overflow-hidden"><img src={p.imageUrl} alt="" className="w-full h-full object-cover" /></div> : <div className="w-10 h-10 bg-slate-100 rounded flex items-center justify-center text-slate-400">-</div>}
                </td>
                <td className="p-3">
                  <div className="flex gap-2">
                    <Link href={`/products/${p.id}`} className="p-1.5 hover:bg-slate-100 rounded" title="详情">
                      <Eye className="w-4 h-4 text-slate-600" />
                    </Link>
                    <Link href={`/products/${p.id}/edit`} className="p-1.5 hover:bg-slate-100 rounded" title="编辑">
                      <Edit className="w-4 h-4 text-blue-600" />
                    </Link>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {products.length === 0 && <div className="p-8 text-center text-slate-500">暂无商品数据</div>}
      </div>
    </div>
  );
}