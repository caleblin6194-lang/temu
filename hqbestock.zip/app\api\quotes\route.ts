import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";

// 获取报价列表 / 创建报价记录
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const merchantId = searchParams.get("merchantId");
    const where: any = {};
    if (merchantId) where.merchantId = parseInt(merchantId);
    
    const quotes = await prisma.supplierQuote.findMany({
      where,
      include: { product: { include: { category: true, deviceModel: true, color: true } }, merchant: true },
      orderBy: { createdAt: "desc" },
      take: 100,
    });
    return NextResponse.json(quotes);
  } catch (error) {
    return NextResponse.json({ error: "获取失败" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { productId, merchantId, supplierPrice, logisticsCost, platformFee, extraCost, note } = body;
    
    const quote = await prisma.supplierQuote.create({
      data: { productId, merchantId, supplierPrice, logisticsCost, platformFee, extraCost: extraCost || 0, note },
    });
    
    return NextResponse.json(quote);
  } catch (error) {
    return NextResponse.json({ error: "创建失败" }, { status: 500 });
  }
}