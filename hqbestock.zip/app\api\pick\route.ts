import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";

// 获取配货任务
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");
    const where: any = {};
    if (status) where.status = status;
    
    const tasks = await prisma.pickTask.findMany({
      where,
      include: { product: { include: { merchant: { include: { market: true } }, category: true, series: true, deviceModel: true, color: true } } },
      orderBy: { createdAt: "desc" },
      take: 100,
    });
    return NextResponse.json(tasks);
  } catch (error) {
    return NextResponse.json({ error: "获取失败" }, { status: 500 });
  }
}

// 创建/更新配货任务
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { productId, quantity, status } = body;
    
    // 检查是否已有任务
    const existing = await prisma.pickTask.findFirst({ where: { productId, status: "pending" } });
    
    let task;
    if (existing) {
      task = await prisma.pickTask.update({
        where: { id: existing.id },
        data: { quantity, status },
      });
    } else {
      task = await prisma.pickTask.create({
        data: { productId, quantity, status: status || "pending" },
      });
    }
    
    return NextResponse.json(task);
  } catch (error) {
    return NextResponse.json({ error: "创建失败" }, { status: 500 });
  }
}