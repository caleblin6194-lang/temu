import prisma from './prisma';

// ==================== SKU 生成器 ====================

// 市场编码映射
const MARKET_CODES: Record<string, string> = {
  '赛格广场': 'SG',
  '华强北电子城': 'HQB',
  '赛博': 'SYB',
  '远望数码城': 'YHD',
};

// 品类编码映射
const CATEGORY_CODES: Record<string, string> = {
  '手机壳': 'SK',
  '充电器': 'CD',
  '数据线': 'SX',
  '钢化膜': 'GM',
  '耳机': 'EJ',
};

// 系列编码映射
const SERIES_CODES: Record<string, string> = {
  '磁吸': 'CX',
  '防摔': 'FS',
  '透明': 'TM',
  '磨砂': 'MS',
  '皮纹': 'PW',
  '超薄': 'CB',
};

// 颜色编码映射
const COLOR_CODES: Record<string, string> = {
  '黑': 'H',
  '白': 'B',
  '蓝': 'L',
  '粉': 'F',
  '绿': 'G',
  '透明': 'T',
  '红': 'R',
  '灰': 'GY',
};

/**
 * 生成 SKU 编码
 * 格式：[市场]-[档口]-[品类]-[系列]-[型号]-[颜色]-[序号]
 * 示例：SG-A12-SK-CX-IP15PM-H-001
 */
export async function generateSkuCode(
  marketCode: string,
  boothCode: string,
  categoryCode: string,
  seriesCode: string,
  modelCode: string,
  colorCode: string
): Promise<string> {
  // 构建基础编码
  const baseCode = `${marketCode}-${boothCode}-${categoryCode}-${seriesCode}-${modelCode}-${colorCode}`;
  
  // 查询同组合下最大的序号
  const lastProduct = await prisma.product.findFirst({
    where: {
      skuCode: { startsWith: baseCode },
    },
    orderBy: { serialNo: 'desc' },
  });
  
  // 计算新序号
  const nextSerialNo = lastProduct ? lastProduct.serialNo + 1 : 1;
  const serialStr = String(nextSerialNo).padStart(3, '0');
  
  return `${baseCode}-${serialStr}`;
}

/**
 * 根据ID生成SKU
 */
export async function generateSkuByIds(
  marketId: number,
  merchantId: number,
  categoryId: number,
  seriesId: number,
  deviceModelId: number,
  colorId: number
): Promise<string> {
  // 获取各字段的编码
  const market = await prisma.market.findUnique({ where: { id: marketId } });
  const merchant = await prisma.merchant.findUnique({ where: { id: merchantId } });
  const category = await prisma.category.findUnique({ where: { id: categoryId } });
  const series = await prisma.series.findUnique({ where: { id: seriesId } });
  const model = await prisma.deviceModel.findUnique({ where: { id: deviceModelId } });
  const color = await prisma.color.findUnique({ where: { id: colorId } });
  
  if (!market || !merchant || !category || !series || !model || !color) {
    throw new Error('Invalid ID provided');
  }
  
  return generateSkuCode(
    market.code,
    merchant.boothCode,
    category.code,
    series.code,
    model.code,
    color.code
  );
}

// ==================== 中文翻译器 ====================

/**
 * SKU 中文翻译
 * SG-A12-SK-CX-IP15PM-H-001
 * => 赛格广场 A12档口｜手机壳｜磁吸｜iPhone 15 Pro Max｜黑色｜001
 */
export async function translateSkuToChinese(skuCode: string): Promise<string> {
  const parts = skuCode.split('-');
  if (parts.length < 7) return skuCode;
  
  const [marketCode, boothCode, categoryCode, seriesCode, modelCode, colorCode] = parts;
  
  // 查询对应的中文名称
  const market = await prisma.market.findUnique({ where: { code: marketCode } });
  const category = await prisma.category.findUnique({ where: { code: categoryCode } });
  const series = await prisma.series.findUnique({ where: { code: seriesCode } });
  const model = await prisma.deviceModel.findUnique({ where: { code: modelCode } });
  const color = await prisma.color.findUnique({ where: { code: colorCode } });
  
  const marketName = market?.name || marketCode;
  const categoryName = category?.name || categoryCode;
  const seriesName = series?.name || seriesCode;
  const modelName = model?.name || modelCode;
  const colorName = color?.name || colorCode;
  
  return `${marketName} ${boothCode}档口｜${categoryName}｜${seriesName}｜${modelName}｜${colorName}`;
}

/**
 * 生成短标签
 * 磁吸壳｜15PM｜黑
 */
export function generateShortLabel(
  seriesName: string,
  modelName: string,
  colorName: string
): string {
  // 简化型号
  const shortModel = modelName
    .replace('iPhone', 'IP')
    .replace('Samsung ', 'SS')
    .replace('Xiaomi ', 'XM')
    .replace(' Pro Max', 'PM')
    .replace(' Pro', 'P')
    .replace(' Plus', '+')
    .replace(' Ultra', 'U');
  
  // 简化颜色
  const colorMap: Record<string, string> = {
    '黑': '黑', '白': '白', '蓝': '蓝', '粉': '粉',
    '绿': '绿', '透明': '透', '红': '红', '灰': '灰',
  };
  const shortColor = colorMap[colorName] || colorName;
  
  return `${seriesName}壳｜${shortModel}｜${shortColor}`;
}

// ==================== 利润计算器 ====================

export interface ProfitCalculation {
  temuPrice: number;
  supplierPrice: number;
  logisticsCost: number;
  platformFee: number;
  extraCost: number;
}

export interface ProfitResult {
 预估利润: number;
  利润率: number;
  建议标签: '推荐' | '可观察' | '不建议';
}

/**
 * 计算利润
 */
export function calculateProfit(data: ProfitCalculation): ProfitResult {
  const { temuPrice, supplierPrice, logisticsCost, platformFee, extraCost } = data;
  
  const 预估利润 = temuPrice - supplierPrice - logisticsCost - platformFee - extraCost;
  const 利润率 = temuPrice > 0 ? (预估利润 / temuPrice) * 100 : 0;
  
  let 建议标签: '推荐' | '可观察' | '不建议';
  if (利润率 >= 30) {
    建议标签 = '推荐';
  } else if (利润率 >= 20) {
    建议标签 = '可观察';
  } else {
    建议标签 = '不建议';
  }
  
  return {
    预估利润: Math.round(预估利润 * 100) / 100,
    利润率: Math.round(利润率 * 100) / 100,
    建议标签,
  };
}

export default prisma;
